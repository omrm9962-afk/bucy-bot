export default {
    command: 'addprem',
    category: 'owner',
    aliases: ['addpremium', 'بريميم'],
    description: 'إضافة مستخدم للبريميم',
    usage: '.addprem (@mention)',
    owner: true,
    async execute({ reply, react, msg, bucy }) {
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const target = mentioned[0] || msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (!target) return await reply('❌ اذكر (@mention) المستخدم');
        await bucy.database.set('premium', target, { addedAt: Date.now() });
        await react('✅');
        await reply(`✅ تمت إضافة *+${target.split('@')[0]}* للبريميم`);
    }
};
