export default {
    command: 'broadcast',
    category: 'owner',
    aliases: ['bc', 'بث'],
    description: 'إرسال رسالة لجميع المجموعات',
    usage: '.broadcast <رسالة>',
    owner: true,
    async execute({ reply, react, args, sock, bucy }) {
        if (!args || args.length === 0) return await reply('❌ اكتب الرسالة بعد الأمر');
        const message = args.join(' ');
        await react('📤');
        const groups = bucy.database?.getAll('groups') || [];
        let sent = 0, failed = 0;
        for (const group of groups) {
            try {
                await sock.sendMessage(group.key + '@g.us', { text: `📢 *إشعار من البوت*\n\n${message}` });
                sent++;
                await new Promise(r => setTimeout(r, 500));
            } catch { failed++; }
        }
        await react('✅');
        await reply(`✅ *تم الإرسال*\n✓ ناجح: ${sent}\n✗ فشل: ${failed}`);
    }
};
