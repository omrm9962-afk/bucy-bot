export default {
    command: 'ban',
    category: 'owner',
    aliases: ['block', 'حظر'],
    description: 'حظر مستخدم من البوت',
    usage: '.ban (@mention)',
    owner: true,
    async execute({ reply, react, msg, bucy }) {
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const target = mentioned[0] || msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (!target) return await reply('❌ اذكر (@mention) المستخدم');
        await bucy.database.set('ban', target, { bannedAt: Date.now() });
        await react('🚫');
        await reply(`🚫 تم حظر *+${target.split('@')[0]}*`);
    }
};
