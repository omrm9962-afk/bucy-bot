export default {
    command: 'hello',
    category: 'general',
    aliases: ['hi', 'مرحبا', 'hola'],
    description: 'ترحيب من البوت',
    usage: '.hello',
    cooldown: 2,
    async execute({ reply, react, msg }) {
        await react('👋');
        const name = msg.pushName || 'صديقي';
        await reply(`👋 *مرحباً ${name}!*\n\nكيف حالك؟ أنا بخير وجاهز لخدمتك 😊\nاكتب *.menu* لعرض الأوامر`);
    }
};
