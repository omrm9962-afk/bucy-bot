export default {
    command: 'promote',
    category: 'group',
    aliases: ['admin', 'ترقية'],
    description: 'ترقية عضو لأدمن',
    usage: '.promote (@mention)',
    cooldown: 3,
    group: true,
    admin: true,
    async execute({ reply, react, sock, msg, isOwner, isAdmin }) {
        if (!isAdmin && !isOwner) return await reply('❌ هذا الأمر للأدمن فقط');
        
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (!mentioned.length) return await reply('❌ اذكر (@mention) الشخص');
        
        try {
            await react('⬆️');
            await sock.groupParticipantsUpdate(msg.key.remoteJid, mentioned, 'promote');
            await reply(`✅ تمت ترقية العضو لأدمن`);
        } catch {
            await react('❌');
            await reply('❌ فشل الترقية');
        }
    }
};
