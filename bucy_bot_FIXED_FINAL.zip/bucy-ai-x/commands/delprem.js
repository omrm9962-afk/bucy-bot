export default {
    command: 'delprem',
    category: 'owner',
    aliases: ['delpremium', 'removepremium'],
    description: 'إزالة مستخدم من البريميم',
    usage: '.delprem (@mention)',
    owner: true,
    async execute({ reply, react, msg, bucy }) {
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const target = mentioned[0] || msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (!target) return await reply('❌ اذكر (@mention) المستخدم');
        await bucy.database.delete('premium', target);
        await react('✅');
        await reply(`✅ تمت إزالة *+${target.split('@')[0]}* من البريميم`);
    }
};
