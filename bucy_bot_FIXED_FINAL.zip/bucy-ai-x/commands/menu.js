export default {
    command: 'menu',
    category: 'general',
    aliases: ['help', 'اوامر', 'قائمة'],
    description: 'عرض قائمة الأوامر',
    usage: '.menu',
    cooldown: 3,
    async execute({ reply, react, bucy }) {
        await react('📋');
        
        const commands = bucy?.commandHandler?.getCommands() || [];
        const categories = [...new Set(commands.map(c => c.category))].sort();
        
        const emojis = {
            general: '📌', owner: '👑', group: '👥', ai: '🤖',
            media: '📥', fun: '🎮', tools: '🔧', system: '⚙️'
        };
        
        let text = `╔══════════════════════════╗\n`;
        text += `║  🤖 *BUCY AI X MENU*       ║\n`;
        text += `╚══════════════════════════╝\n\n`;
        text += `👤 *By MARO* | v${bucy?.botVersion || '2.0.0'}\n`;
        text += `⚡ *Prefix:* ${bucy?.botPrefix || '.'}\n`;
        text += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (const category of categories) {
            const cmds = commands.filter(c => c.category === category);
            if (!cmds.length) continue;
            
            const emoji = emojis[category] || '📌';
            text += `${emoji} *${category.toUpperCase()}* (${cmds.length})\n`;
            
            for (const cmd of cmds) {
                let badges = '';
                if (cmd.owner) badges += '👑';
                if (cmd.premium) badges += '⭐';
                if (cmd.group) badges += '👥';
                text += `  ▸ .${cmd.command}${badges ? ' ' + badges : ''}\n`;
            }
            text += '\n';
        }
        
        text += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        text += `📊 *Total:* ${commands.length} commands\n`;
        text += `📢 t.me/MARO_EMPOSTER`;
        
        await reply(text);
    }
};
