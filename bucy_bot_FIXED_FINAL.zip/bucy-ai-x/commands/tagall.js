export default {
    command: 'tagall',
    category: 'group',
    aliases: ['mentionall', 'الكل'],
    description: 'منشن جميع أعضاء المجموعة',
    usage: '.tagall <رسالة>',
    cooldown: 30,
    group: true,
    admin: true,
    async execute({ reply, react, sock, msg, args }) {
        await react('📢');
        const metadata = await sock.groupMetadata(msg.key.remoteJid);
        const members = metadata.participants.map(p => p.id);
        const message = args.join(' ') || '📢 *تنبيه!*';
        
        let text = `${message}\n\n`;
        members.forEach(m => text += `@${m.split('@')[0]} `);
        
        await sock.sendMessage(msg.key.remoteJid, {
            text,
            mentions: members
        });
    }
};
