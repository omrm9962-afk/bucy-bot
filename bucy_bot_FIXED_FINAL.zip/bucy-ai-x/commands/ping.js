export default {
    command: 'ping',
    category: 'general',
    aliases: ['speed', 'latency'],
    description: 'فحص سرعة البوت',
    usage: '.ping',
    cooldown: 3,
    async execute({ reply, react }) {
        const start = Date.now();
        await react('⏱️');
        const ping = Date.now() - start;
        await reply(`🏓 *PONG!*\n⚡ Speed: *${ping}ms*\n🤖 Bot is Online`);
    }
};
