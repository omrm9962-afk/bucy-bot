import os from 'os';
export default {
    command: 'stats',
    category: 'general',
    aliases: ['info', 'status', 'احصائيات'],
    description: 'إحصائيات البوت',
    usage: '.stats',
    cooldown: 5,
    async execute({ reply, bucy }) {
        const mem = process.memoryUsage();
        const uptime = Math.floor(process.uptime());
        const d = Math.floor(uptime / 86400);
        const h = Math.floor((uptime % 86400) / 3600);
        const m = Math.floor((uptime % 3600) / 60);
        const s = uptime % 60;
        const uptimeStr = `${d}d ${h}h ${m}m ${s}s`;
        const heapMB = Math.round(mem.heapUsed / 1024 / 1024);
        const totalMB = Math.round(mem.heapTotal / 1024 / 1024);
        const users = bucy?.database?.count('users') || 0;
        const groups = bucy?.database?.count('groups') || 0;
        const cmds = bucy?.commandHandler?.commands?.size || 0;
        const msgs = bucy?.messageCount || 0;

        await reply(`╔══════════════════════╗
║  📊 *BUCY AI X STATS* ║
╚══════════════════════╝

🤖 *Bot:* ${bucy?.botName || 'BUCY AI X'}
👤 *Author:* MARO
📦 *Version:* ${bucy?.botVersion || '2.0.0'}

📊 *Statistics:*
├ 👥 Users: *${users}*
├ 🏠 Groups: *${groups}*
├ ⚡ Commands: *${cmds}*
└ 💬 Messages: *${msgs}*

💻 *System:*
├ 🔋 RAM: *${heapMB}/${totalMB} MB*
├ ⏱️ Uptime: *${uptimeStr}*
├ 🟢 Node: *${process.version}*
└ 🖥️ OS: *${os.platform()}*`);
    }
};
