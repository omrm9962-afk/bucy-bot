export default {
    command: 'owner',
    category: 'general',
    aliases: ['dev', 'developer', 'مطور'],
    description: 'معلومات المطور',
    usage: '.owner',
    cooldown: 5,
    async execute({ reply }) {
        await reply(`👑 *Bot Developer*

🧑‍💻 *Name:* MARO
📢 *Channel:* https://t.me/MARO_EMPOSTER
👥 *Group:* https://t.me/maro_chat12
🤖 *Telegram:* @ANM_IV

💡 *Bot:* BUCY AI X v2.0.0
🔧 *Engine:* Baileys 7 + Node.js 22`);
    }
};
