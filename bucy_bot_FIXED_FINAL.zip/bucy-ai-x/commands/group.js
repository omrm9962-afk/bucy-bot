export default {
    command: 'group',
    category: 'group',
    aliases: ['grp'],
    description: 'معلومات المجموعة',
    usage: '.group',
    cooldown: 3,
    group: true,
    async execute({ reply, sock, msg }) {
        try {
            const metadata = await sock.groupMetadata(msg.key.remoteJid);
            const admins = metadata.participants.filter(p => p.admin).map(p => p.id.split('@')[0]);
            const members = metadata.participants.length;
            
            await reply(`╔══════════════════════╗
║  👥 *Group Info*       ║
╚══════════════════════╝

📌 *Name:* ${metadata.subject}
👤 *Members:* ${members}
👑 *Admins:* ${admins.length}
📅 *Created:* ${new Date(metadata.creation * 1000).toLocaleDateString('ar')}

👑 *Admins:*
${admins.map(a => `├ +${a}`).join('\n')}`);
        } catch (err) {
            await reply(`❌ فشل جلب معلومات المجموعة`);
        }
    }
};
