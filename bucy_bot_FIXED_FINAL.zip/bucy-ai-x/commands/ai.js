export default {
    command: 'ai',
    category: 'ai',
    aliases: ['gpt', 'chat', 'ask', 'ذكاء'],
    description: 'تحدث مع الذكاء الاصطناعي',
    usage: '.ai <سؤالك>',
    cooldown: 5,
    async execute({ reply, react, args, msg }) {
        if (!args || args.length === 0) {
            return await reply(`🤖 *Usage:* .ai <سؤالك>\n\nمثال: .ai ما هي عاصمة مصر؟`);
        }
        await react('🤔');
        const question = args.join(' ');
        const apiKey = process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY;
        
        if (!apiKey) {
            return await reply(`❌ *AI غير متاح*\nيرجى إضافة GEMINI_API_KEY في ملف .env`);
        }

        try {
            // Try Gemini first
            if (process.env.GEMINI_API_KEY) {
                const { GoogleGenerativeAI } = await import('@google/generative-ai').catch(() => ({ GoogleGenerativeAI: null }));
                if (GoogleGenerativeAI) {
                    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
                    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
                    const result = await model.generateContent(question);
                    const text = result.response.text();
                    await react('✅');
                    return await reply(`🤖 *AI Response:*\n\n${text}`);
                }
            }
            await react('❌');
            await reply(`❌ فشل الاتصال بـ AI`);
        } catch (err) {
            await react('❌');
            await reply(`❌ *خطأ في AI:* ${err.message}`);
        }
    }
};
