export default {
    command: 'runtime',
    category: 'general',
    aliases: ['uptime', 'وقت'],
    description: 'مدة تشغيل البوت',
    usage: '.runtime',
    cooldown: 3,
    async execute({ reply }) {
        const uptime = Math.floor(process.uptime());
        const d = Math.floor(uptime / 86400);
        const h = Math.floor((uptime % 86400) / 3600);
        const m = Math.floor((uptime % 3600) / 60);
        const s = uptime % 60;
        await reply(`⏱️ *Runtime:* ${d}d ${h}h ${m}m ${s}s`);
    }
};
