export default {
    command: 'help',
    category: 'general',
    aliases: ['مساعدة', 'h'],
    description: 'مساعدة لأمر معين',
    usage: '.help <command>',
    cooldown: 3,
    async execute({ reply, args, bucy }) {
        if (!args || args.length === 0) {
            return await reply(`📖 *Usage:* .help <command>\n\nExample: .help ping\n\nUse *.menu* to see all commands`);
        }
        const cmdName = args[0].toLowerCase().replace(/^\./, '');
        const cmd = bucy?.commandHandler?.commands?.get(cmdName);
        if (!cmd) return await reply(`❌ Command *${cmdName}* not found.\nUse *.menu* to see all commands`);
        
        let text = `📖 *Command Help: .${cmd.command}*\n\n`;
        text += `📝 *Description:* ${cmd.description || 'N/A'}\n`;
        text += `🔧 *Usage:* ${cmd.usage || '.' + cmd.command}\n`;
        text += `📂 *Category:* ${cmd.category || 'General'}\n`;
        if (cmd.aliases?.length) text += `🔗 *Aliases:* ${cmd.aliases.join(', ')}\n`;
        if (cmd.cooldown) text += `⏳ *Cooldown:* ${cmd.cooldown}s\n`;
        if (cmd.owner) text += `👑 *Owner Only*\n`;
        if (cmd.premium) text += `⭐ *Premium Only*\n`;
        if (cmd.group) text += `👥 *Groups Only*\n`;
        
        await reply(text);
    }
};
