export default {
    command: 'unban',
    category: 'owner',
    aliases: ['unblock', 'رفع حظر'],
    description: 'رفع حظر مستخدم',
    usage: '.unban (@mention)',
    owner: true,
    async execute({ reply, react, msg, bucy }) {
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const target = mentioned[0] || msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (!target) return await reply('❌ اذكر (@mention) المستخدم');
        await bucy.database.delete('ban', target);
        await react('✅');
        await reply(`✅ تم رفع حظر *+${target.split('@')[0]}*`);
    }
};
