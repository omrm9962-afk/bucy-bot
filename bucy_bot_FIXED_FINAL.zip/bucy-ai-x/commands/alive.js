export default {
    command: 'alive',
    category: 'general',
    aliases: ['online', 'شغال'],
    description: 'تحقق أن البوت شغال',
    usage: '.alive',
    cooldown: 3,
    async execute({ reply, bucy }) {
        const uptime = Math.floor(process.uptime());
        const h = Math.floor(uptime / 3600);
        const m = Math.floor((uptime % 3600) / 60);
        const s = uptime % 60;
        
        await reply(`╔══════════════════════╗
║  🤖 *BUCY AI X*        ║
╚══════════════════════╝

✅ *البوت شغال!*
⏱️ Uptime: *${h}h ${m}m ${s}s*
👤 Author: *MARO*
📦 Version: *${bucy?.botVersion || '2.0.0'}*
⚡ Prefix: *${bucy?.botPrefix || '.'}*

🔗 t.me/MARO_EMPOSTER`);
    }
};
