export default {
    command: 'kick',
    category: 'group',
    aliases: ['remove', 'طرد'],
    description: 'طرد عضو من المجموعة',
    usage: '.kick (@mention)',
    cooldown: 3,
    group: true,
    admin: true,
    async execute({ reply, react, sock, msg, isOwner, isAdmin }) {
        if (!isAdmin && !isOwner) return await reply('❌ هذا الأمر للأدمن فقط');
        
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
                         msg.message?.extendedTextMessage?.contextInfo?.participant 
                         ? [msg.message?.extendedTextMessage?.contextInfo?.participant] : [];
        
        if (!mentioned.length) return await reply('❌ اذكر (@mention) الشخص المراد طرده');
        
        try {
            await react('🚫');
            await sock.groupParticipantsUpdate(msg.key.remoteJid, mentioned, 'remove');
            await reply(`✅ تم طرد ${mentioned.length} عضو`);
        } catch {
            await react('❌');
            await reply('❌ فشل طرد العضو (تأكد من صلاحيات البوت)');
        }
    }
};
