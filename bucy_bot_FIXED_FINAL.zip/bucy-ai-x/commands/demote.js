export default {
    command: 'demote',
    category: 'group',
    aliases: ['unadmin', 'تخفيض'],
    description: 'إزالة صلاحيات الأدمن',
    usage: '.demote (@mention)',
    cooldown: 3,
    group: true,
    admin: true,
    async execute({ reply, react, sock, msg, isOwner, isAdmin }) {
        if (!isAdmin && !isOwner) return await reply('❌ هذا الأمر للأدمن فقط');
        
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (!mentioned.length) return await reply('❌ اذكر (@mention) الشخص');
        
        try {
            await react('⬇️');
            await sock.groupParticipantsUpdate(msg.key.remoteJid, mentioned, 'demote');
            await reply(`✅ تمت إزالة صلاحيات الأدمن`);
        } catch {
            await react('❌');
            await reply('❌ فشل التخفيض');
        }
    }
};
