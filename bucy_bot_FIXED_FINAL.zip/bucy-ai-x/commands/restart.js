export default {
    command: 'restart',
    category: 'owner',
    aliases: ['reboot', 'إعادة تشغيل'],
    description: 'إعادة تشغيل البوت',
    usage: '.restart',
    owner: true,
    async execute({ reply, react }) {
        await react('🔄');
        await reply('🔄 *إعادة تشغيل البوت...*\nانتظر بضع ثوانٍ');
        setTimeout(() => {
            if (globalThis.BUCY_RESTART) globalThis.BUCY_RESTART();
            else process.exit(0);
        }, 2000);
    }
};
