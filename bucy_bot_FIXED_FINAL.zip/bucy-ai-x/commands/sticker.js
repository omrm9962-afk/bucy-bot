export default {
    command: 'sticker',
    category: 'media',
    aliases: ['s', 'ستيكر'],
    description: 'تحويل صورة إلى ستيكر',
    usage: '.sticker (رد على صورة)',
    cooldown: 5,
    async execute({ reply, react, sock, msg }) {
        await react('⏳');
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const imageMsg = quoted?.imageMessage || msg.message?.imageMessage;
        
        if (!imageMsg) {
            await react('❌');
            return await reply(`❌ *ارد على صورة* أو أرسل صورة مع الأمر`);
        }

        try {
            const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');
            const stream = await downloadContentFromMessage(imageMsg, 'image');
            const chunks = [];
            for await (const chunk of stream) chunks.push(chunk);
            const buffer = Buffer.concat(chunks);
            
            await sock.sendMessage(msg.key.remoteJid, {
                sticker: buffer,
                mimetype: 'image/webp'
            }, { quoted: msg });
            await react('✅');
        } catch (err) {
            await react('❌');
            await reply(`❌ فشل تحويل الصورة: ${err.message}`);
        }
    }
};
