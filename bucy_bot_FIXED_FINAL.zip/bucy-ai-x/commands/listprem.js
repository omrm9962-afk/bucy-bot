export default {
    command: 'listprem',
    category: 'owner',
    aliases: ['premlist', 'قائمة بريميم'],
    description: 'قائمة مستخدمي البريميم',
    usage: '.listprem',
    owner: true,
    async execute({ reply, bucy }) {
        const list = bucy.database?.getAll('premium') || [];
        if (!list.length) return await reply('📋 لا يوجد مستخدمون بريميم');
        let text = `⭐ *Premium Users (${list.length})*\n\n`;
        list.forEach((u, i) => text += `${i+1}. +${u.key?.split('@')[0] || u.key}\n`);
        await reply(text);
    }
};
