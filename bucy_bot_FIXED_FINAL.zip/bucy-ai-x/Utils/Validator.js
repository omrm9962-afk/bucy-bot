// ================================================================
// FILE: Utils/Validator.js
// ================================================================
// BUCY AI X - VALIDATOR
// ================================================================

class Validator {
    constructor(bucy) {
        this.bucy = bucy;
    }

    validatePhoneNumber(number) {
        const cleaned = number.replace(/\D/g, '');
        if (cleaned.length < 10 || cleaned.length > 15) {
            return { valid: false, error: 'Invalid phone number length' };
        }
        return { valid: true, cleaned };
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return { valid: false, error: 'Invalid email format' };
        }
        return { valid: true };
    }

    validateUrl(url) {
        try {
            new URL(url);
            return { valid: true };
        } catch {
            return { valid: false, error: 'Invalid URL' };
        }
    }

    validateInteger(value) {
        const num = Number(value);
        if (!Number.isInteger(num)) {
            return { valid: false, error: 'Not an integer' };
        }
        return { valid: true, value: num };
    }

    validatePositiveNumber(value) {
        const num = Number(value);
        if (isNaN(num) || num <= 0) {
            return { valid: false, error: 'Must be a positive number' };
        }
        return { valid: true, value: num };
    }

    validateCommandName(name) {
        if (!name || typeof name !== 'string') {
            return { valid: false, error: 'Invalid command name' };
        }
        if (!/^[a-zA-Z0-9_]+$/.test(name)) {
            return { valid: false, error: 'Command name can only contain letters, numbers, and underscore' };
        }
        return { valid: true };
    }

    isInRange(value, min, max) {
        return value >= min && value <= max;
    }

    isJsonString(str) {
        try {
            JSON.parse(str);
            return true;
        } catch {
            return false;
        }
    }
}

export default Validator;