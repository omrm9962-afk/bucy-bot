// ================================================================
// FILE: Utils/Simple.js
// ================================================================
// BUCY AI X - SIMPLE UTILITY FUNCTIONS
// ================================================================

import chalk from 'chalk';
import os from 'os';

export class Simple {
    static formatTime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        parts.push(`${secs}s`);
        
        return parts.join(' ');
    }

    static formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    static formatNumber(num) {
        if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
        if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
        return num.toString();
    }

    static randomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    static shuffleArray(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    static extractUrls(text) {
        const urlRegex = /https?:\/\/[^\s]+/g;
        return text.match(urlRegex) || [];
    }

    static hasUrl(text) {
        const urlRegex = /https?:\/\/[^\s]+/g;
        return urlRegex.test(text);
    }

    static sanitize(text) {
        return text
            .replace(/[<>]/g, '')
            .replace(/['"]/g, '')
            .replace(/[\\/]/g, '')
            .trim();
    }

    static sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    static getSystemInfo() {
        const mem = process.memoryUsage();
        return {
            platform: os.platform(),
            arch: os.arch(),
            cpus: os.cpus().length,
            totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024),
            freeMemory: Math.round(os.freemem() / 1024 / 1024 / 1024),
            processMemory: Math.round(mem.heapUsed / 1024 / 1024),
            uptime: process.uptime(),
            pid: process.pid,
            nodeVersion: process.version
        };
    }

    static logSystemInfo() {
        const info = this.getSystemInfo();
        console.log(chalk.dim('════════════════════════════════════════════════════════════════'));
        console.log(chalk.cyan('📊 System Information:'));
        console.log(chalk.white(`  🖥️  OS: ${info.platform} ${info.arch}`));
        console.log(chalk.white(`  💻 CPU: ${info.cpus} cores`));
        console.log(chalk.white(`  🧠 RAM: ${info.totalMemory}GB Total, ${info.freeMemory}GB Free`));
        console.log(chalk.white(`  🔄 Memory: ${info.processMemory}MB`));
        console.log(chalk.white(`  ⏱️  Uptime: ${this.formatTime(info.uptime)}`));
        console.log(chalk.white(`  📦 Node: ${info.nodeVersion}`));
        console.log(chalk.white(`  🆔 PID: ${info.pid}`));
        console.log(chalk.dim('════════════════════════════════════════════════════════════════'));
        console.log('\n');
    }

    static generateId(length = 8) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    static isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    static isValidPhone(phone) {
        const cleaned = phone.replace(/\D/g, '');
        return cleaned.length >= 10 && cleaned.length <= 15;
    }
}

export default Simple;