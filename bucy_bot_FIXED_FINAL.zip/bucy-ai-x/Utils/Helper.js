// ================================================================
// FILE: Utils/Helper.js
// ================================================================
// BUCY AI X - HELPER FUNCTIONS
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Helper {
    constructor(bucy) {
        this.bucy = bucy;
    }

    async createDirectories() {
        const directories = [
            '../Sessions',
            '../Data',
            '../Logs',
            '../Temp',
            '../Backups',
            '../Database',
            '../Cache',
            '../Media',
            '../Plugins'
        ];

        for (const dir of directories) {
            const fullPath = path.join(__dirname, dir);
            if (!await fs.pathExists(fullPath)) {
                await fs.mkdir(fullPath, { recursive: true });
                this.bucy.logger?.info(`📁 Created directory: ${dir}`);
            }
        }
    }

    async cleanTempFiles() {
        const tempDir = path.join(__dirname, '../Temp');
        if (!await fs.pathExists(tempDir)) return;

        const files = await fs.readdir(tempDir);
        const now = Date.now();
        
        for (const file of files) {
            const filePath = path.join(tempDir, file);
            const stats = await fs.stat(filePath);
            const age = (now - stats.mtimeMs) / 1000 / 60;
            
            if (age > 60) {
                await fs.remove(filePath);
                this.bucy.logger?.info(`🗑️ Deleted old temp file: ${file}`);
            }
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    randomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    shuffleArray(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    isUrl(text) {
        const urlRegex = /https?:\/\/[^\s]+/g;
        return urlRegex.test(text);
    }

    extractUrls(text) {
        const urlRegex = /https?:\/\/[^\s]+/g;
        return text.match(urlRegex) || [];
    }

    sanitize(text) {
        return text
            .replace(/[<>]/g, '')
            .replace(/['"]/g, '')
            .replace(/[\\/]/g, '')
            .trim();
    }
}

export default Helper;