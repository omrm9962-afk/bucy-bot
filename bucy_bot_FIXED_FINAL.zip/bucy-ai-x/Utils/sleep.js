// ================================================================
// FILE: Utils/sleep.js
// ================================================================
// BUCY AI X - SLEEP FUNCTION
// ================================================================

export function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

export function sleepWithCancel(ms, signal) {
    return new Promise((resolve, reject) => {
        const timer = setTimeout(resolve, ms);
        if (signal) {
            signal.addEventListener('abort', () => {
                clearTimeout(timer);
                reject(new Error('Sleep cancelled'));
            });
        }
    });
}

export default { sleep, sleepWithCancel };