// ================================================================
// FILE: Utils/MessageBuilder.js
// ================================================================
// BUCY AI X - MESSAGE BUILDER
// ================================================================

class MessageBuilder {
    constructor(bucy) {
        this.bucy = bucy;
    }

    async send(jid, content, options = {}) {
        try {
            if (!this.bucy.sock) {
                throw new Error('No socket connection');
            }
            return await this.bucy.sock.sendMessage(jid, content, options);
        } catch (error) {
            this.bucy.logger?.error('Failed to send message:', error);
            throw error;
        }
    }

    async sendText(jid, text, options = {}) {
        return await this.send(jid, { text }, options);
    }

    async sendMenu(jid, title, items, options = {}) {
        let menuText = `╔══════════════════════════════════╗\n`;
        menuText += `║       ${title}       ║\n`;
        menuText += `╠══════════════════════════════════╣\n`;
        for (const item of items) {
            menuText += `║ ${item.prefix || '▸'} ${item.name}`;
            if (item.description) {
                menuText += `\n║    ${item.description}`;
            }
            menuText += `\n`;
        }
        menuText += `╚══════════════════════════════════╝`;
        return await this.sendText(jid, menuText, options);
    }

    async sendCard(jid, title, content, footer = '', options = {}) {
        const cardText = `📌 *${title}*\n\n${content}\n\n${footer}`;
        return await this.sendText(jid, cardText, options);
    }

    async sendStatsCard(jid, stats, options = {}) {
        let statsText = `📊 *Statistics*\n\n`;
        statsText += `╔══════════════════════════════════╗\n`;
        for (const [key, value] of Object.entries(stats)) {
            const paddedKey = key.padEnd(20);
            const paddedValue = String(value).padStart(10);
            statsText += `║ ${paddedKey} ${paddedValue} ║\n`;
        }
        statsText += `╚══════════════════════════════════╝`;
        return await this.sendText(jid, statsText, options);
    }
}

export default MessageBuilder;