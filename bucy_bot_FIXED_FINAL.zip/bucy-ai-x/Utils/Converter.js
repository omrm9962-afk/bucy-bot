// ================================================================
// FILE: Utils/Converter.js
// ================================================================
// BUCY AI X - CONVERTER
// ================================================================

class Converter {
    constructor(bucy) {
        this.bucy = bucy;
    }

    toBase64(text) {
        return Buffer.from(text).toString('base64');
    }

    fromBase64(base64) {
        return Buffer.from(base64, 'base64').toString('utf8');
    }

    toHex(text) {
        return Buffer.from(text).toString('hex');
    }

    fromHex(hex) {
        return Buffer.from(hex, 'hex').toString('utf8');
    }

    secondsToTime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        parts.push(`${secs}s`);
        
        return parts.join(' ');
    }

    timeToSeconds(timeString) {
        const parts = timeString.match(/(\d+)([dhms])/g);
        if (!parts) return 0;
        
        let seconds = 0;
        for (const part of parts) {
            const value = parseInt(part);
            const unit = part.slice(-1);
            switch (unit) {
                case 'd': seconds += value * 86400; break;
                case 'h': seconds += value * 3600; break;
                case 'm': seconds += value * 60; break;
                case 's': seconds += value; break;
            }
        }
        return seconds;
    }

    bytesToSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    sizeToBytes(sizeString) {
        const units = { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 };
        const match = sizeString.match(/^(\d+(?:\.\d+)?)\s*([KMGT]?B)$/i);
        if (!match) return 0;
        const [, value, unit] = match;
        return parseFloat(value) * (units[unit.toUpperCase()] || 1);
    }
}

export default Converter;