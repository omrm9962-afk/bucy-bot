// ================================================================
// FILE: main.js (FIXED - NO TOP-LEVEL AWAIT & CORRECT IMPORT)
// ================================================================

import makeWASocket, { 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion 
} from '@whiskeysockets/baileys';

import fs from 'fs-extra';
import pino from 'pino';
import path from 'path';
import chalk from 'chalk';
import readline from 'readline';
import { spawn } from 'child_process';
import process from 'process';
import os from 'os';

import Logger from './Services/Logger.js';
import config from './Config/BucyConfig.js';
import BucyXMaro from './BucyXMaro.js';
import Settings from './Config/Settings.js';
import MessageService from './Services/MessageService.js';

const BOT_NAME = config.name || 'BUCY AI X';
const BOT_VERSION = config.version || '2.0.0';
const BOT_AUTHOR = config.author || 'MARO';

// ================================================================
// ✅ LOAD SETTINGS (NO TOP-LEVEL AWAIT)
// ================================================================

let settings = null;

async function loadSettings() {
    if (settings) return settings;
    const s = new Settings();
    await s.load();
    settings = s;
    return settings;
}

// ================================================================
// STATE MANAGER
// ================================================================

const State = {
    bot: null,
    socket: null,
    healthTimer: null,
    reconnectTimer: null,
    isStarting: false,
    isStopping: false,
    isHealthRunning: false,
    healthChecks: 0,
    startTime: null,
    listenersRegistered: false,
    reconnectAttempts: 0,
    maxReconnectAttempts: 5,

    canStart() {
        return !this.isStarting && !this.isStopping;
    },

    clearTimers() {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.healthTimer) {
            clearTimeout(this.healthTimer);
            this.healthTimer = null;
        }
        this.isHealthRunning = false;
    },

    cleanupSocket(sock) {
        if (!sock) return false;
        try {
            if (sock.ev) sock.ev.removeAllListeners();
            if (sock.ws) sock.ws.close();
            if (sock.end) sock.end();
            if (sock.close) sock.close();
        } catch (e) {}
        if (this.socket === sock) this.socket = null;
        return true;
    },

    reset() {
        this.bot = null;
        this.socket = null;
        this.isStarting = false;
        this.isStopping = false;
        this.clearTimers();
        this.reconnectAttempts = 0;
    },

    incrementReconnectAttempts() {
        this.reconnectAttempts++;
        return this.reconnectAttempts;
    },

    canReconnect() {
        return this.reconnectAttempts < this.maxReconnectAttempts;
    },

    resetReconnectAttempts() {
        this.reconnectAttempts = 0;
    }
};

const logger = new Logger();

function safeCpu() {
    try {
        const c = os.cpus();
        return { cores: c?.length || 0 };
    } catch { return { cores: 0 }; }
}

function safeCount(db, col) {
    try { return db && typeof db.count === 'function' ? db.count(col) || 0 : 0; } catch { return 0; }
}

function formatUptime(sec) {
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    const parts = [];
    if (d) parts.push(d + 'd');
    if (h) parts.push(h + 'h');
    if (m) parts.push(m + 'm');
    parts.push(s + 's');
    return parts.join(' ');
}

function question(text) {
    return new Promise(r => {
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl.question(text, a => { rl.close(); r(a); });
    });
}

function updateHealth() {
    const mem = process.memoryUsage();
    const load = os.loadavg();
    const total = os.totalmem();
    const free = os.freemem();
    const cpu = safeCpu();

    State.healthChecks++;

    const data = {
        uptime: Math.floor(process.uptime()),
        uptimeFormatted: formatUptime(process.uptime()),
        healthChecks: State.healthChecks,
        memory: {
            heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
            heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
            rss: Math.round(mem.rss / 1024 / 1024),
            total: Math.round(total / 1024 / 1024 / 1024),
            free: Math.round(free / 1024 / 1024 / 1024),
            usagePercent: Math.round(((total - free) / total) * 100)
        },
        cpu: {
            loadavg: load.map(v => Math.round(v * 100) / 100),
            cores: cpu.cores
        },
        process: { pid: process.pid, version: process.version, platform: os.platform() },
        isRunning: State.bot?.isRunning || false,
        isConnected: !!State.socket,
        users: safeCount(State.bot?.database, 'users'),
        groups: safeCount(State.bot?.database, 'groups'),
        commands: State.bot?.commandCount || 0,
        messages: State.bot?.messageCount || 0,
        errors: State.bot?.errorCount || 0,
        timestamp: Date.now()
    };

    globalThis.BucyHealth = data;
    return data;
}

function startHealthMonitor() {
    if (State.isHealthRunning) return;
    State.isHealthRunning = true;
    State.clearTimers();

    updateHealth();
    logger.info('Health monitor started');

    const loop = async () => {
        if (State.isStopping) {
            State.isHealthRunning = false;
            return;
        }
        try {
            updateHealth();
        } catch (e) {
            logger.error('Health error:', e);
        }
        if (!State.isStopping) {
            State.healthTimer = setTimeout(loop, 30000);
        } else {
            State.isHealthRunning = false;
        }
    };

    loop();
}

function stopHealthMonitor() {
    State.isHealthRunning = false;
    State.clearTimers();
    logger.info('Health monitor stopped');
}

function registerListeners() {
    if (State.listenersRegistered) return;
    State.listenersRegistered = true;

    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));

    process.on('uncaughtException', async (e) => {
        console.log('\n' + chalk.red('╔══════════════════════════════════════════════════════════════╗'));
        console.log(chalk.red('║') + chalk.white('                    UNCAUGHT EXCEPTION                          ') + chalk.red('║'));
        console.log(chalk.red('╚══════════════════════════════════════════════════════════════╝') + '\n');
        logger.error('Uncaught exception:', e);
        console.error(e.stack);
        await shutdown('Fatal: ' + e.message);
    });

    process.on('unhandledRejection', (reason) => {
        logger.warn('Unhandled rejection:', reason);
        if (reason?.stack) console.error(reason.stack);
    });

    logger.info('Process listeners ready');
}

export async function shutdown(reason = 'Shutdown') {
    if (State.isStopping) return;
    State.isStopping = true;
    State.clearTimers();

    console.log('\n' + chalk.red('╔══════════════════════════════════════════════════════════════╗'));
    console.log(chalk.red('║') + chalk.yellow('                    SHUTTING DOWN                            ') + chalk.red('║'));
    console.log(chalk.red('╚══════════════════════════════════════════════════════════════╝') + '\n');

    logger.warn('Shutdown:', reason);

    try {
        stopHealthMonitor();
        State.cleanupSocket(State.socket);
        State.socket = null;

        if (State.bot) {
            await State.bot.shutdown();
            State.bot = null;
        }

        State.reset();
        console.log('\n' + chalk.green('✓ BUCY AI X shut down successfully') + '\n');
        process.exit(0);
    } catch (e) {
        logger.error('Shutdown error:', e);
        console.error(e.stack);
        process.exit(1);
    }
}

export async function restart() {
    if (State.isStopping) {
        logger.warn('Already stopping');
        return;
    }

    logger.warn('Restarting...');
    State.isStopping = true;
    State.clearTimers();

    stopHealthMonitor();
    State.cleanupSocket(State.socket);
    State.socket = null;

    if (State.bot) {
        await State.bot.shutdown();
        State.bot = null;
    }

    State.reset();

    const args = process.argv.slice(1);
    const child = spawn(process.argv[0], args, {
        cwd: process.cwd(),
        detached: true,
        stdio: 'inherit',
        env: process.env,
        windowsHide: true
    });
    child.unref();

    process.exit(0);
}

async function attemptReconnect() {
    if (!State.canReconnect()) {
        logger.error('❌ Max reconnect attempts reached');
        await shutdown('Max reconnect attempts');
        return;
    }

    const attempt = State.incrementReconnectAttempts();
    const delay = Math.min(5000 * attempt, 60000);

    logger.info(`🔄 Reconnect attempt ${attempt}/${State.maxReconnectAttempts} in ${delay}ms`);

    State.clearTimers();
    State.reconnectTimer = setTimeout(async () => {
        State.reconnectTimer = null;
        if (State.canStart()) {
            await startBot();
        }
    }, delay);
}

export async function startBot() {
    if (!State.canStart()) {
        logger.warn('Cannot start - already running or stopping');
        return;
    }

    State.clearTimers();

    if (State.bot) {
        logger.warn('Cleaning old instance...');
        try {
            State.cleanupSocket(State.socket);
            State.socket = null;
            await State.bot.shutdown();
        } catch (e) {}
        State.bot = null;
    }

    State.isStarting = true;
    State.startTime = Date.now();

    registerListeners();

    try {
        logger.info('Starting BUCY AI X...');
        const cpu = safeCpu();
        logger.info(`Node ${process.version} | ${os.platform()} | PID: ${process.pid} | CPU: ${cpu.cores} cores`);

        // ✅ LOAD SETTINGS (NO TOP-LEVEL AWAIT)
        await loadSettings();

        const sessionDir = path.join(process.cwd(), 'Sessions');
        await fs.ensureDir(sessionDir);

        const bot = new BucyXMaro();
        State.bot = bot;

        bot.settings = settings;
        bot.messageService = new MessageService(bot);

        await bot.initialize();

        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestBaileysVersion();

        if (State.socket) {
            State.cleanupSocket(State.socket);
            State.socket = null;
        }

        const sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            browser: ['Ubuntu', 'Chrome', '22.04'],
            logger: pino({ level: 'silent' }),
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true
        });

        State.socket = sock;
        bot.sock = sock;
        bot.saveCreds = saveCreds;

        if (!state.creds.registered) {
            console.log(chalk.bold.hex('#9B59B6')('\n[ SETUP ] Enter phone number:'));
            let num = await question(chalk.bgHex('#9B59B6').black(' Number: '));
            if (num.trim() === '#') process.exit(0);
            num = num.replace(/\D/g, '');
            if (!num.match(/^\d{10,15}$/)) { logger.error('Invalid number'); process.exit(1); }
            try {
                const code = await sock.requestPairingCode(num);
                console.log('\n────────── Pairing ──────────');
                console.log(chalk.hex('#9B59B6').bold(`Code: ${code}`));
                console.log(chalk.cyanBright(`Number: ${num}`));
                console.log('─────────────────────────────\n');
            } catch (e) {
                logger.error('Pairing failed, trying QR...');
                sock.printQRInTerminal = true;
            }
        }

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'connecting') logger.info('Connecting...');
            if (connection === 'open') {
                logger.success('Connected!');
                State.resetReconnectAttempts();
                bot.isRunning = true;
                bot.botNumber = sock.user.id.split(':')[0].replace(/\D/g, '');

                bot.startMessageHandler();
                State.isStarting = false;

                const elapsed = Date.now() - State.startTime;
                logger.success(`Ready in ${elapsed}ms`);

                console.log('\n' + chalk.hex('#9B59B6')('📊 Bot Info:'));
                console.log(chalk.white(`  🤖 ${BOT_NAME}`));
                console.log(chalk.white(`  📱 ${sock.user.id}`));
                console.log(chalk.white(`  🟢 Online | PID: ${process.pid}`));
                console.log(chalk.white(`  ⏱️ ${elapsed}ms`));
                console.log('\n' + chalk.dim('═══════════════════════════════════════'));
                console.log(chalk.dim('  💡 .menu  - Commands'));
                console.log(chalk.dim('  💡 .ping  - Check'));
                console.log(chalk.dim('  💡 .stats - Statistics'));
                console.log(chalk.dim('═══════════════════════════════════════') + '\n');

                globalThis.BucyXMaro = bot;
                globalThis.BUCY_RESTART = restart;
                globalThis.BUCY_SHUTDOWN = shutdown;
                globalThis.BUCY_VERSION = BOT_VERSION;

                startHealthMonitor();

                logger.success('BUCY AI X ready!');
            }

            if (connection === 'close') {
                const code = lastDisconnect?.error?.output?.statusCode || 'unknown';
                logger.warn(`Disconnected (${code})`);

                if (code === DisconnectReason.loggedOut || code === 401) {
                    bot.isRunning = false;
                    State.cleanupSocket(sock);
                    State.socket = null;
                    await shutdown('Logged out');
                    return;
                }

                bot.isRunning = false;
                State.cleanupSocket(sock);
                State.socket = null;
                State.isStarting = false;

                await attemptReconnect();
            }
        });

        sock.ev.on('messages.upsert', async (m) => {
            try {
                if (bot.messageHandler) await bot.messageHandler.handleMessages(sock, m);
            } catch (e) { logger.error('Message error:', e); }
        });

        sock.ev.on('group-participants.update', async (u) => {
            try {
                if (bot.eventHandler) await bot.eventHandler.handleGroupUpdate(u);
            } catch (e) { logger.error('Group error:', e); }
        });

        sock.ev.on('creds.update', saveCreds);

    } catch (error) {
        State.isStarting = false;
        console.log('\n' + chalk.red('╔══════════════════════════════════╗'));
        console.log(chalk.red('║') + chalk.white('          STARTUP FAILED            ') + chalk.red('║'));
        console.log(chalk.red('╚══════════════════════════════════╝') + '\n');
        console.error('========== FULL ERROR ==========');
        console.error('Message:', error.message);
        console.error('Code:', error.code || 'N/A');
        console.error('Stack:');
        console.error(error.stack);
        console.error('==================================\n');

        logger.error('Startup error:', error);

        State.cleanupSocket(State.socket);
        State.socket = null;
        if (State.bot) { try { await State.bot.shutdown(); } catch (e) {} State.bot = null; }
        State.clearTimers();

        await attemptReconnect();
    }
}

globalThis.BucyXMaro = null;
globalThis.BucyHealth = {};
globalThis.BUCY_RESTART = restart;
globalThis.BUCY_SHUTDOWN = shutdown;
globalThis.BUCY_VERSION = BOT_VERSION;

export default { startBot, shutdown, restart };
