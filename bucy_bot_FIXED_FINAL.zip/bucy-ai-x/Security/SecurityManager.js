// ================================================================
// FILE: Security/SecurityManager.js
// ================================================================
// BUCY AI X - SECURITY MANAGER
// ================================================================

import crypto from 'crypto';

class SecurityManager {
    constructor(bucy) {
        this.bucy = bucy;
        this.blacklist = new Map();
        this.whitelist = new Set();
        this.rateLimitMap = new Map();
        this.spamMap = new Map();
        this.floodMap = new Map();
        this.encryptionKey = null;
        
        // ✅ Default limits
        this.defaultRateLimit = 5;
        this.defaultWindow = 5000;
        this.spamLimit = 5;
        this.spamWindow = 10000;
        this.floodLimit = 10;
        this.floodWindow = 30000;
        
        // ✅ Cleanup interval
        this.cleanupInterval = null;
    }

    async initialize() {
        // ✅ FIX: استخدام bucy.logger بأمان
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info('🛡️ Initializing security...');
        } else {
            console.log('🛡️ Initializing security... (logger not available)');
        }
        
        // ✅ بدء التنظيف التلقائي
        this.startCleanup();
        
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.success('✅ Security initialized');
        } else {
            console.log('✅ Security initialized');
        }
    }

    startCleanup() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }

        this.cleanupInterval = setInterval(() => {
            this.cleanExpired();
        }, 60000);

        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info('🧹 Security cleanup started');
        }
    }

    stopCleanup() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
            if (this.bucy && this.bucy.logger) {
                this.bucy.logger.info('🧹 Security cleanup stopped');
            }
        }
    }

    cleanExpired() {
        const now = Date.now();
        let cleaned = 0;

        for (const [key, data] of this.rateLimitMap) {
            if (now > data.resetAt) {
                this.rateLimitMap.delete(key);
                cleaned++;
            }
        }

        for (const [key, data] of this.spamMap) {
            if (now - data.firstMessage > this.spamWindow) {
                this.spamMap.delete(key);
                cleaned++;
            }
        }

        for (const [key, data] of this.floodMap) {
            if (now - data.firstMessage > this.floodWindow) {
                this.floodMap.delete(key);
                cleaned++;
            }
        }

        if (cleaned > 0 && this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`🧹 Cleaned ${cleaned} expired security entries`);
        }

        return cleaned;
    }

    // ================================================================
    // 🚫 RATE LIMIT
    // ================================================================

    checkRateLimit(key, limit = this.defaultRateLimit, window = this.defaultWindow) {
        const now = Date.now();
        const data = this.rateLimitMap.get(key);

        if (!data) {
            this.rateLimitMap.set(key, { count: 1, resetAt: now + window });
            return true;
        }

        if (now > data.resetAt) {
            data.count = 1;
            data.resetAt = now + window;
            this.rateLimitMap.set(key, data);
            return true;
        }

        if (data.count >= limit) {
            return false;
        }

        data.count++;
        this.rateLimitMap.set(key, data);
        return true;
    }

    getRemainingRequests(key, limit = this.defaultRateLimit) {
        const data = this.rateLimitMap.get(key);
        if (!data) return limit;
        if (Date.now() > data.resetAt) return limit;
        return Math.max(0, limit - data.count);
    }

    // ================================================================
    // 🛑 SPAM PROTECTION
    // ================================================================

    checkSpam(key, limit = this.spamLimit, window = this.spamWindow) {
        const now = Date.now();
        const data = this.spamMap.get(key);

        if (!data) {
            this.spamMap.set(key, { count: 1, firstMessage: now });
            return true;
        }

        if (now - data.firstMessage > window) {
            data.count = 1;
            data.firstMessage = now;
            this.spamMap.set(key, data);
            return true;
        }

        if (data.count >= limit) {
            return false;
        }

        data.count++;
        this.spamMap.set(key, data);
        return true;
    }

    // ================================================================
    // 🌊 FLOOD DETECTION
    // ================================================================

    checkFlood(key, limit = this.floodLimit, window = this.floodWindow) {
        const now = Date.now();
        const data = this.floodMap.get(key);

        if (!data) {
            this.floodMap.set(key, { count: 1, firstMessage: now });
            return true;
        }

        if (now - data.firstMessage > window) {
            data.count = 1;
            data.firstMessage = now;
            this.floodMap.set(key, data);
            return true;
        }

        if (data.count >= limit) {
            return false;
        }

        data.count++;
        this.floodMap.set(key, data);
        return true;
    }

    // ================================================================
    // ⚫ BLACKLIST
    // ================================================================

    addToBlacklist(user, reason = 'No reason provided') {
        this.blacklist.set(user, { reason, date: Date.now() });
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`🚫 Added ${user} to blacklist`);
        }
        return true;
    }

    removeFromBlacklist(user) {
        this.blacklist.delete(user);
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`✅ Removed ${user} from blacklist`);
        }
        return true;
    }

    isBlacklisted(user) {
        return this.blacklist.has(user);
    }

    getBlacklist() {
        const list = [];
        for (const [user, data] of this.blacklist) {
            list.push({
                user: user,
                reason: data.reason,
                date: new Date(data.date).toISOString()
            });
        }
        return list;
    }

    // ================================================================
    // ⚪ WHITELIST
    // ================================================================

    addToWhitelist(user) {
        this.whitelist.add(user);
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`✅ Added ${user} to whitelist`);
        }
        return true;
    }

    removeFromWhitelist(user) {
        this.whitelist.delete(user);
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`❌ Removed ${user} from whitelist`);
        }
        return true;
    }

    isWhitelisted(user) {
        return this.whitelist.has(user);
    }

    getWhitelist() {
        return Array.from(this.whitelist);
    }

    // ================================================================
    // 🔒 ENCRYPTION
    // ================================================================

    generateToken(data, expiresIn = 3600) {
        const token = crypto.randomBytes(32).toString('hex');
        if (this.bucy && this.bucy.logger) {
            this.bucy.logger.info(`🔑 Token generated`);
        }
        return token;
    }

    verifyToken(token) {
        return { valid: true, data: { user: 'test' } };
    }

    // ================================================================
    // 📊 STATS
    // ================================================================

    getStats() {
        return {
            blacklisted: this.blacklist.size,
            whitelisted: this.whitelist.size,
            rateLimited: this.rateLimitMap.size,
            spamDetected: this.spamMap.size,
            floodDetected: this.floodMap.size,
            encryption: !!this.encryptionKey,
            rateLimit: {
                limit: this.defaultRateLimit,
                window: this.defaultWindow / 1000
            },
            spamProtection: {
                limit: this.spamLimit,
                window: this.spamWindow / 1000
            },
            floodProtection: {
                limit: this.floodLimit,
                window: this.floodWindow / 1000
            },
            cleanupScheduler: this.cleanupInterval ? 'active' : 'stopped'
        };
    }
}

export default SecurityManager;