// ================================================================
// FILE: BucyTelegramBridge.js
// ================================================================
// BUCY AI X - TELEGRAM BRIDGE
// ================================================================

import { Telegraf, Markup } from 'telegraf';
import chalk from 'chalk';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import QRCode from 'qrcode';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const BUCY_CONFIG = {
    token: process.env.TELEGRAM_BOT_TOKEN || '8672931190:AAFOOnzbi_Jm3RKzEFIoK0RPkPiux66GuXg',
    support: '@ANM_IV',
    channel: 'https://t.me/MARO_EMPOSTER',
    botName: '𝑩𝒖𝒄𝒚 𝑩𝒐𝒕',
    owner: ['ANM_IV'],
    developers: ['7697500717'],
    allowedUsernames: [
        'maro_chat12',
        'MARO_EMPOSTER',
        'MARO_I_M_P_O_S_T_A_R_VIP',
        'MARO_TEAM_EMPOSTER',
        'TEAM_EL_EMPOSTER'
    ],
    welcomeSticker: 'CAACAgQAAxkBAAIGQWotGOMWC51y4FECoJgev81y5LLCAAKIHgACH0gQUChpcECzdrsXPAQ'
};

const premiumFile = path.join(__dirname, 'Database/bucy_premium.json');
let premiumUsers = [];

async function loadPremiumUsers() {
    try {
        if (await fs.pathExists(premiumFile)) {
            const data = await fs.readJson(premiumFile);
            premiumUsers = data || [];
            console.log(chalk.green(`✅ Loaded ${premiumUsers.length} Premium Users`));
        } else {
            premiumUsers = ['7697500717'];
            await fs.writeJson(premiumFile, premiumUsers, { spaces: 2 });
        }
    } catch (err) {
        premiumUsers = ['7697500717'];
    }
}

async function savePremiumUsers() {
    try {
        await fs.writeJson(premiumFile, premiumUsers, { spaces: 2 });
    } catch (err) {}
}

function isPremium(userId) {
    return premiumUsers.includes(userId.toString());
}

function isOwner(ctx) {
    const userId = ctx.from?.id?.toString();
    const username = ctx.from?.username;
    const isDev = BUCY_CONFIG.developers.includes(userId);
    const isOwner = BUCY_CONFIG.owner.includes(username);
    const isAllowed = BUCY_CONFIG.allowedUsernames.includes(username);
    return isDev || isOwner || isAllowed;
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (days > 0) return `${days} يوم, ${hours} ساعة, ${minutes} دقيقة`;
    if (hours > 0) return `${hours} ساعة, ${minutes} دقيقة, ${secs} ثانية`;
    if (minutes > 0) return `${minutes} دقيقة, ${secs} ثانية`;
    return `${secs} ثانية`;
}

class BucyTelegramBridge {
    constructor() {
        this.bot = null;
        this.isRunning = false;
        this.startTime = Date.now();
        this.cooldowns = new Map();
    }

    async initialize() {
        try {
            await loadPremiumUsers();
            this.bot = new Telegraf(BUCY_CONFIG.token);
            this.setupHandlers();
            this.setupCallbackHandlers();
            await this.bot.launch();
            this.isRunning = true;
            console.log(chalk.green('✅ Telegram bridge started'));
            process.once('SIGINT', () => this.bot.stop('SIGINT'));
            process.once('SIGTERM', () => this.bot.stop('SIGTERM'));
        } catch (error) {
            console.error('Failed to start Telegram bridge:', error);
        }
    }

    setupHandlers() {
        this.bot.command('start', async (ctx) => {
            const startMessage = `𝘏𝘖́Ł𝘈 𝙈𝘼𝙍𝙊 𝙀𝙇 𝙔𝙊𝙐𝙏𝙐𝘽𝙀𝙍 , ⛧ 𝘞𝘌𝘓𝘊𝘖𝘔𝘌 𝘛𝘖 𝘋𝘈𝘙𝘒 𝘞𝘖𝘙𝘓𝘋 ⛧ 👄\n𝖳𝖮 𝖫𝖤𝖠𝖱𝖭 𝖧𝖮𝖶 𝖡𝖮𝖳 𝖶𝖮𝖱𝖪 𝖠𝖭𝖣 𝖢𝖫𝖨𝖢𝖪 /menu 🫧`;
            const keyboard = Markup.inlineKeyboard([
                [Markup.button.url('𝗢𝗪𝗡𝗘𝗥', 'https://t.me/ANM_IV')],
                [Markup.button.url('𝗚𝗥𝗢𝗨𝗣', 'https://t.me/maro_chat12')],
                [Markup.button.url('𝗖𝗛𝗔𝗡𝗡𝗘𝗟', 'https://t.me/MARO_EMPOSTER')]
            ]);
            await ctx.replyWithHTML(startMessage, keyboard);
            await ctx.replyWithSticker(BUCY_CONFIG.welcomeSticker);
        });

        this.bot.command('menu', async (ctx) => {
            const menuText = `
╔═══ 🍷 ━━━━━━━━━━━━ ═══╗
     🏴☠️ <b>𝗕𝗨𝗖𝗬 𝗔𝗜 𝗫</b> 🏴☠️
╚═══ 💰 ━━━━━━━━━━━━ ═══╝

📋 <b>Commands:</b>
🔗 /connect - Pair WhatsApp
🕒 /runtime - Uptime
🏓 /ping - Check status
👑 /premium - Premium status
📊 /stats - Statistics

<b>📢 Channel:</b> ${BUCY_CONFIG.channel}
<b>👤 Support:</b> ${BUCY_CONFIG.support}`;

            const keyboard = Markup.inlineKeyboard([
                [Markup.button.url('📢 Channel', BUCY_CONFIG.channel)],
                [Markup.button.url('👤 Support', `https://t.me/${BUCY_CONFIG.support.replace('@', '')}`)]
            ]);
            await ctx.replyWithHTML(menuText, keyboard);
        });

        this.bot.command('connect', async (ctx) => {
            const args = ctx.message.text.split(' ').slice(1);
            if (args.length === 0) {
                return ctx.replyWithHTML('📱 Usage: /connect <phone_number>\nExample: /connect 201012345678');
            }
            const phoneNumber = args[0].replace(/\D/g, '');
            const keyboard = Markup.inlineKeyboard([
                [Markup.button.callback('🔢 Pairing Code', `pair_code_${phoneNumber}`)],
                [Markup.button.callback('📱 QR Code', `pair_qr_${phoneNumber}`)],
                [Markup.button.callback('❌ Cancel', 'pair_cancel')]
            ]);
            await ctx.replyWithHTML(`📱 <b>Pairing</b>\nNumber: <code>${phoneNumber}</code>\nChoose method:`, keyboard);
        });

        this.bot.command('runtime', async (ctx) => {
            await ctx.replyWithHTML(`⏱️ <b>Uptime:</b> ${formatUptime(process.uptime())}`);
        });

        this.bot.command('ping', async (ctx) => {
            const start = Date.now();
            await ctx.replyWithHTML('🏓 Pinging...');
            const ping = Date.now() - start;
            await ctx.replyWithHTML(`🏓 <b>Pong!</b>\n⚡ <b>Speed:</b> <code>${ping}ms</code>`);
        });

        this.bot.command('premium', async (ctx) => {
            const userId = ctx.from.id.toString();
            const status = isPremium(userId) ? '✅ Premium Member' : '❌ Free User';
            await ctx.replyWithHTML(`👑 <b>Premium Status</b>\n👤 <b>User:</b> <code>${userId}</code>\n📊 <b>Status:</b> ${status}`);
        });

        this.bot.command('addpremium', async (ctx) => {
            if (!isOwner(ctx)) return ctx.replyWithHTML('⚠️ Access Denied');
            const args = ctx.message.text.split(' ').slice(1);
            let targetId = args[0] || ctx.message.reply_to_message?.from?.id?.toString();
            if (!targetId) return ctx.replyWithHTML('Usage: /addpremium <user_id>');
            if (premiumUsers.includes(targetId)) return ctx.replyWithHTML('Already premium');
            premiumUsers.push(targetId);
            await savePremiumUsers();
            ctx.replyWithHTML(`✅ Premium added: <code>${targetId}</code>`);
        });

        this.bot.command('listpremium', async (ctx) => {
            if (!isOwner(ctx)) return ctx.replyWithHTML('⚠️ Access Denied');
            let list = `👑 Premium Users (${premiumUsers.length})\n\n`;
            premiumUsers.forEach((id, i) => list += `<b>${i+1}</b>. <code>${id}</code>\n`);
            await ctx.replyWithHTML(list);
        });

        this.bot.command('delpremium', async (ctx) => {
            if (!isOwner(ctx)) return ctx.replyWithHTML('⚠️ Access Denied');
            const args = ctx.message.text.split(' ').slice(1);
            let targetId = args[0] || ctx.message.reply_to_message?.from?.id?.toString();
            if (!targetId) return ctx.replyWithHTML('Usage: /delpremium <user_id>');
            if (!premiumUsers.includes(targetId)) return ctx.replyWithHTML('User is not premium');
            premiumUsers = premiumUsers.filter(id => id !== targetId);
            await savePremiumUsers();
            ctx.replyWithHTML(`❌ Premium removed: <code>${targetId}</code>`);
        });
    }

    setupCallbackHandlers() {
        this.bot.action(/pair_code_(.+)/, async (ctx) => {
            const number = ctx.match[1];
            await ctx.answerCbQuery('Generating code...');
            const code = Math.floor(100000 + Math.random() * 900000);
            await ctx.editMessageText(`✅ <b>Pairing Code</b>\n📱 <code>${number}</code>\n🔑 <code>${code}</code>\n<i>Enter this code in WhatsApp</i>`, { parse_mode: 'HTML' });
        });

        this.bot.action(/pair_qr_(.+)/, async (ctx) => {
            const number = ctx.match[1];
            await ctx.answerCbQuery('Generating QR...');
            const qrBuffer = await QRCode.toBuffer(`https://wa.me/${number}?text=Pairing`);
            await ctx.replyWithPhoto({ source: qrBuffer }, { caption: `✅ QR Code for ${number}` });
            await ctx.editMessageText('✅ QR Code sent above.');
        });

        this.bot.action('pair_cancel', async (ctx) => {
            await ctx.answerCbQuery('Cancelled');
            await ctx.editMessageText('❌ Cancelled');
        });
    }

    getStatus() {
        return {
            isRunning: this.isRunning,
            uptime: process.uptime(),
            uptimeFormatted: formatUptime(process.uptime()),
            premiumUsers: premiumUsers.length
        };
    }
}

export default BucyTelegramBridge;