// ================================================================
// FILE: index.js (FIXED)
// ================================================================

import chalk from 'chalk';
import os from 'os';
import process from 'process';
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs-extra';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env if present
try {
    const { config } = await import('dotenv');
    config({ path: path.join(__dirname, '.env') });
} catch {}

// ================================================================
// 🚀 STARTUP BANNER
// ================================================================

function showStartupBanner() {
    const totalMem = Math.round(os.totalmem() / 1024 / 1024 / 1024);
    const freeMem = Math.round(os.freemem() / 1024 / 1024 / 1024);

    console.log(chalk.bold.hex('#9B59B6')("\n╔══════════════════════════════════════════════╗"));
    console.log(chalk.bold.hex('#9B59B6')("║    𝗕𝗨𝗖𝗬 𝗔𝗜 𝗫 v2.0.0 - By MARO            ║"));
    console.log(chalk.bold.hex('#9B59B6')("╚══════════════════════════════════════════════╝\n"));
    console.log(chalk.dim(`  Node: ${process.version} | OS: ${os.platform()} | PID: ${process.pid}`));
    console.log(chalk.dim(`  RAM: ${totalMem}GB Total, ${freeMem}GB Free\n`));
}

// ================================================================
// 🚀 MAIN
// ================================================================

async function main() {
    try {
        showStartupBanner();

        // 1️⃣ تشغيل البوت
        console.log(chalk.dim('📱 Starting WhatsApp Bot...'));
        const { startBot } = await import('./main.js');
        await startBot();
        console.log(chalk.green('✅ WhatsApp Bot started'));

        // 2️⃣ تشغيل التيليجرام
        // ✅ FIX: Check env var OR hardcoded token in BucyTelegramBridge
        const telegramToken = process.env.TELEGRAM_BOT_TOKEN || '8672931190:AAFOOnzbi_Jm3RKzEFIoK0RPkPiux66GuXg';
        if (telegramToken && telegramToken.includes(':')) {
            console.log(chalk.dim('📱 Starting Telegram Bridge...'));
            try {
                // Set env var so BucyTelegramBridge can read it
                process.env.TELEGRAM_BOT_TOKEN = telegramToken;
                const { default: BucyTelegramBridge } = await import('./BucyTelegramBridge.js');
                const telegram = new BucyTelegramBridge();
                await telegram.initialize();
                console.log(chalk.green('✅ Telegram Bridge started'));
            } catch (error) {
                console.log(chalk.yellow(`⚠️ Telegram Bridge failed: ${error.message}`));
            }
        } else {
            console.log(chalk.yellow('⚠️ No Telegram token, skipping'));
        }

        // 3️⃣ تشغيل الداشبورد
        console.log(chalk.dim('🌐 Starting Dashboard...'));
        try {
            const { default: dashboard } = await import('./Dashboard/server.js');
            const port = process.env.DASHBOARD_PORT || process.env.PORT || 3000;
            console.log(chalk.green('✅ Dashboard started'));
            console.log(chalk.cyan(`   🌐 URL: http://0.0.0.0:${port}`));
            console.log(chalk.cyan(`   👤 User: admin | 🔑 Pass: admin123`));
        } catch (error) {
            console.log(chalk.yellow(`⚠️ Dashboard failed: ${error.message}`));
        }

        // ✅ DONE
        console.log('\n' + chalk.green('╔══════════════════════════════════════════════╗'));
        console.log(chalk.green('║  ✅ BUCY AI X IS FULLY RUNNING               ║'));
        console.log(chalk.green('║  💡 .menu → all commands                     ║'));
        console.log(chalk.green('║  🌐 Dashboard → http://0.0.0.0:3000          ║'));
        console.log(chalk.green('╚══════════════════════════════════════════════╝\n'));

    } catch (error) {
        console.log(chalk.red(`\n❌ STARTUP FAILED: ${error.message}`));
        console.error(error.stack);
        process.exit(1);
    }
}

main();
export default main;
