// ================================================================
// FILE: Scripts/BucyStats.js
// ================================================================
// BUCY AI X - STATS SCRIPT
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function showStats() {
    console.log('📊 BUCY AI X Statistics\n');

    // Database stats
    const dbPath = path.join(__dirname, '../Database');
    if (await fs.pathExists(dbPath)) {
        const files = await fs.readdir(dbPath);
        console.log('📁 Database:');
        for (const file of files) {
            if (file.endsWith('.json')) {
                const data = await fs.readJson(path.join(dbPath, file));
                const count = Object.keys(data).length;
                console.log(`  - ${file}: ${count} entries`);
            }
        }
    }

    // Sessions stats
    const sessionPath = path.join(__dirname, '../Sessions');
    if (await fs.pathExists(sessionPath)) {
        const sessions = await fs.readdir(sessionPath);
        console.log(`\n📱 Sessions: ${sessions.length} active`);
    }

    // Logs stats
    const logPath = path.join(__dirname, '../Logs');
    if (await fs.pathExists(logPath)) {
        const logs = await fs.readdir(logPath);
        console.log(`\n📝 Logs: ${logs.length} files`);
    }
}

showStats().catch(console.error);