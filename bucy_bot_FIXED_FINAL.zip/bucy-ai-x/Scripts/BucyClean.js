// ================================================================
// FILE: Scripts/BucyClean.js
// ================================================================
// BUCY AI X - CLEAN SCRIPT
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function clean() {
    console.log('🧹 Cleaning BUCY AI X...');

    const dirs = ['Temp', 'Cache', 'Logs', 'Backups'];
    for (const dir of dirs) {
        const dirPath = path.join(__dirname, '..', dir);
        if (await fs.pathExists(dirPath)) {
            await fs.emptyDir(dirPath);
            console.log(`✅ Cleaned: ${dir}`);
        }
    }

    console.log('✅ Clean complete!');
}

clean().catch(console.error);