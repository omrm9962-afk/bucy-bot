// ================================================================
// FILE: Scripts/BucyBackup.js
// ================================================================
// BUCY AI X - BACKUP SCRIPT
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import archiver from 'archiver';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function createBackup() {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(__dirname, '../Backups');
    const backupFile = path.join(backupDir, `backup_${timestamp}.zip`);

    await fs.ensureDir(backupDir);

    const output = fs.createWriteStream(backupFile);
    const archive = archiver('zip', { zlib: { level: 9 } });

    return new Promise((resolve, reject) => {
        output.on('close', () => {
            console.log(`✅ Backup created: ${backupFile} (${archive.pointer()} bytes)`);
            resolve(backupFile);
        });

        archive.on('error', (err) => reject(err));

        archive.pipe(output);

        // Add directories
        const dirs = ['Database', 'Sessions', 'Data', 'Config'];
        for (const dir of dirs) {
            const dirPath = path.join(__dirname, '..', dir);
            if (fs.existsSync(dirPath)) {
                archive.directory(dirPath, dir);
            }
        }

        archive.finalize();
    });
}

createBackup().catch(console.error);