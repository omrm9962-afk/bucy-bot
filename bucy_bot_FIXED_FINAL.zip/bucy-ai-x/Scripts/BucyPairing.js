// ================================================================
// FILE: Scripts/BucyPairing.js
// ================================================================
// BUCY AI X - PAIRING SCRIPT (REAL BAILEYS PAIRING)
// ================================================================

import { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    fetchLatestBaileysVersion,
    DisconnectReason 
} from '@whiskeysockets/baileys';
import pino from 'pino';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';
import chalk from 'chalk';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ================================================================
// 📌 FUNCTIONS
// ================================================================

function question(text) {
    return new Promise(resolve => {
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl.question(text, answer => { rl.close(); resolve(answer); });
    });
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    parts.push(`${secs}s`);
    return parts.join(' ');
}

// ================================================================
// 🔐 MAIN PAIRING FUNCTION
// ================================================================

async function startPairing() {
    console.log(chalk.bold.hex('#9B59B6')('\n╔══════════════════════════════════════════════════════════════╗'));
    console.log(chalk.bold.hex('#9B59B6')('║  🔐 BUCY AI X - PAIRING SYSTEM                               ║'));
    console.log(chalk.bold.hex('#9B59B6')('╚══════════════════════════════════════════════════════════════╝\n'));

    const phoneNumber = await question(chalk.yellow('📱 Enter phone number (with country code): '));
    const cleaned = phoneNumber.replace(/\D/g, '');

    if (!cleaned.match(/^\d{10,15}$/)) {
        console.log(chalk.red('\n❌ Invalid phone number. Must be 10-15 digits.\n'));
        process.exit(1);
    }

    console.log(chalk.cyan(`\n📱 Phone: ${cleaned}`));
    console.log(chalk.dim('⏳ Starting pairing process...\n'));

    const sessionDir = path.join(__dirname, '../Sessions', cleaned);
    
    if (await fs.pathExists(sessionDir)) {
        const overwrite = await question(chalk.yellow('⚠️ Session already exists. Overwrite? (y/n): '));
        if (overwrite.toLowerCase() !== 'y') {
            console.log(chalk.dim('\n❌ Pairing cancelled.\n'));
            process.exit(0);
        }
        await fs.remove(sessionDir);
        console.log(chalk.dim('🗑️ Old session removed.\n'));
    }

    await fs.ensureDir(sessionDir);

    try {
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestBaileysVersion();

        console.log(chalk.dim(`📡 Baileys Version: ${version.join('.')}`));

        const sock = makeWASocket({
            version,
            auth: state,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['BUCY AI X', 'Chrome', '120.0.0.0'],
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true
        });

        sock.ev.on('creds.update', saveCreds);

        console.log(chalk.dim('🔄 Requesting pairing code from WhatsApp...'));

        let pairingCode = null;
        let pairingAttempts = 0;
        const maxAttempts = 3;

        while (pairingAttempts < maxAttempts && !pairingCode) {
            try {
                pairingAttempts++;
                pairingCode = await sock.requestPairingCode(cleaned);
            } catch (error) {
                console.log(chalk.yellow(`⚠️ Attempt ${pairingAttempts} failed: ${error.message}`));
                if (pairingAttempts < maxAttempts) {
                    console.log(chalk.dim(`⏳ Retrying in 3 seconds...`));
                    await new Promise(resolve => setTimeout(resolve, 3000));
                }
            }
        }

        if (!pairingCode) {
            console.log(chalk.red('\n❌ Failed to get pairing code after multiple attempts.\n'));
            process.exit(1);
        }

        console.log(chalk.green('\n╔══════════════════════════════════════════════════════════════╗'));
        console.log(chalk.green('║  ✅ PAIRING CODE GENERATED                                  ║'));
        console.log(chalk.green('╚══════════════════════════════════════════════════════════════╝\n'));

        console.log(chalk.white(`  📱 Phone: ${chalk.cyan(cleaned)}`));
        console.log(chalk.white(`  🔑 Code:  ${chalk.bold.hex('#9B59B6')(pairingCode)}`));
        console.log(chalk.dim(`  ⏱️  Expires in: 5 minutes`));
        console.log(chalk.dim(`  🔄 Status: Waiting for connection...\n`));

        console.log(chalk.dim('════════════════════════════════════════════════════════════════'));
        console.log(chalk.dim('  💡 Instructions:'));
        console.log(chalk.dim('  1. Open WhatsApp on your phone'));
        console.log(chalk.dim('  2. Go to Settings > Linked Devices'));
        console.log(chalk.dim('  3. Tap on "Link a Device"'));
        console.log(chalk.dim(`  4. Enter the code: ${chalk.bold.hex('#9B59B6')(pairingCode)}`));
        console.log(chalk.dim('════════════════════════════════════════════════════════════════\n'));

        const pairingInfo = {
            phone: cleaned,
            code: pairingCode,
            createdAt: Date.now(),
            expiresAt: Date.now() + 300000,
            status: 'pending',
            browser: 'BUCY AI X'
        };

        const pairingFile = path.join(__dirname, '../Data/pairing.json');
        let pairingData = {};
        if (await fs.pathExists(pairingFile)) {
            pairingData = await fs.readJson(pairingFile);
        }
        pairingData[cleaned] = pairingInfo;
        await fs.writeJson(pairingFile, pairingData, { spaces: 2 });

        console.log(chalk.dim('💾 Pairing info saved to Data/pairing.json\n'));

        let connected = false;
        let startTime = Date.now();
        const timeout = 120000;

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'open') {
                connected = true;
                console.log(chalk.green('\n╔══════════════════════════════════════════════════════════════╗'));
                console.log(chalk.green('║  ✅ CONNECTED SUCCESSFULLY!                                 ║'));
                console.log(chalk.green('╚══════════════════════════════════════════════════════════════╝\n'));

                pairingInfo.status = 'connected';
                pairingInfo.connectedAt = Date.now();
                pairingData[cleaned] = pairingInfo;
                await fs.writeJson(pairingFile, pairingData, { spaces: 2 });

                console.log(chalk.white(`  📱 Phone: ${chalk.cyan(cleaned)}`));
                console.log(chalk.white(`  🆔 User:  ${chalk.cyan(sock.user?.id || 'Unknown')}`));
                console.log(chalk.white(`  ⏱️  Time:  ${chalk.cyan(new Date().toLocaleString())}`));
                console.log(chalk.dim('\n✅ You can now use the bot!\n'));

                process.exit(0);
            }

            if (connection === 'close') {
                const code = lastDisconnect?.error?.output?.statusCode || 'unknown';
                if (code === DisconnectReason.loggedOut) {
                    console.log(chalk.red('\n❌ You have been logged out. Please try again.\n'));
                    process.exit(1);
                }
            }
        });

        const timeoutInterval = setInterval(() => {
            if (connected) {
                clearInterval(timeoutInterval);
                return;
            }

            const elapsed = Date.now() - startTime;
            if (elapsed > timeout) {
                clearInterval(timeoutInterval);
                console.log(chalk.yellow('\n╔══════════════════════════════════════════════════════════════╗'));
                console.log(chalk.yellow('║  ⏱️ PAIRING TIMEOUT                                         ║'));
                console.log(chalk.yellow('╚══════════════════════════════════════════════════════════════╝\n'));
                console.log(chalk.white(`  📱 Phone: ${chalk.cyan(cleaned)}`));
                console.log(chalk.white(`  🔑 Code:  ${chalk.bold.hex('#9B59B6')(pairingCode)}`));
                console.log(chalk.dim(`  ⏱️  Timeout after 2 minutes`));
                console.log(chalk.dim(`  🔄 Status: ${chalk.yellow('Expired')}\n`));

                pairingInfo.status = 'expired';
                pairingData[cleaned] = pairingInfo;
                await fs.writeJson(pairingFile, pairingData, { spaces: 2 });

                console.log(chalk.dim('💡 Tips:'));
                console.log(chalk.dim('  1. Make sure WhatsApp is open on your phone'));
                console.log(chalk.dim('  2. Check your internet connection'));
                console.log(chalk.dim(`  3. Try again with: node Scripts/BucyPairing.js\n`));

                process.exit(0);
            }
        }, 5000);

        console.log(chalk.dim('⏳ Waiting for connection... (timeout: 2 minutes)\n'));

    } catch (error) {
        console.log(chalk.red('\n❌ Pairing error:'), error.message);
        if (error.stack) console.log(chalk.dim(error.stack));
        console.log(chalk.dim('\n💡 Please try again.\n'));
        process.exit(1);
    }
}

// ================================================================
// 🚀 START
// ================================================================

startPairing().catch(error => {
    console.error(chalk.red('Fatal error:'), error);
    process.exit(1);
});