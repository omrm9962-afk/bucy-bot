// ================================================================
// FILE: BucyXMaro.js
// ================================================================
// BUCY AI X - MAIN ENGINE (FIXED)
// ================================================================

import EventEmitter from 'events';
import config from './Config/BucyConfig.js';

class BucyXMaro extends EventEmitter {
    constructor() {
        super();
        
        this.sock = null;
        this.store = null;
        this.saveCreds = null;
        this.isRunning = false;
        this.initialized = false;
        this.isShuttingDown = false;
        this.botNumber = null;
        this.botName = config.name || 'BUCY AI X';
        this.botVersion = config.version || '2.0.0';
        this.botAuthor = config.author || 'MARO';
        this.botPrefix = config.prefix || '.';
        this.messageCount = 0;
        this.commandCount = 0;
        this.errorCount = 0;
        this.startTime = Date.now();

        this.logger = null;
        this.database = null;
        this.commandHandler = null;
        this.eventHandler = null;
        this.messageHandler = null;
        this.pluginManager = null;
        this.statistics = null;
        this.cacheManager = null;
        this.securityManager = null;
        this.sessionManager = null;
        this.pairingManager = null;
        this.settings = null;
        this.messageService = null;
        this.formatter = null;
        this.helper = null;
        this.validator = null;
        this.converter = null;
        this.messageBuilder = null;
        this.healthMonitor = null;
        this.recovery = null;
    }

    // ✅ FIX: Add sendMessage proxy method
    async sendMessage(jid, content, options = {}) {
        if (!this.sock) throw new Error('Socket not connected');
        return await this.sock.sendMessage(jid, content, options);
    }

    async initialize() {
        if (this.initialized) {
            this.logger?.warn('Bot already initialized');
            return this;
        }

        const Logger = (await import('./Services/Logger.js')).default;
        this.logger = new Logger();
        this.logger.info('Initializing BUCY AI X...');

        try {
            const Database = (await import('./Services/Database.js')).default;
            const CommandHandler = (await import('./Handlers/CommandHandler.js')).default;
            const EventHandler = (await import('./Handlers/EventHandler.js')).default;
            const MessageHandler = (await import('./Handlers/MessageHandler.js')).default;
            const PluginManager = (await import('./Services/PluginManager.js')).default;
            const Statistics = (await import('./Services/Statistics.js')).default;
            const CacheManager = (await import('./Managers/CacheManager.js')).default;
            const SecurityManager = (await import('./Security/SecurityManager.js')).default;
            const SessionManager = (await import('./Managers/SessionManager.js')).default;
            const PairingManager = (await import('./Services/PairingManager.js')).default;
            const HealthMonitor = (await import('./Services/HealthMonitor.js')).default;
            const BucyRecovery = (await import('./Services/BucyRecovery.js')).default;
            const Formatter = (await import('./Utils/Formatter.js')).default;
            const Helper = (await import('./Utils/Helper.js')).default;
            const Validator = (await import('./Utils/Validator.js')).default;
            const Converter = (await import('./Utils/Converter.js')).default;
            const MessageBuilder = (await import('./Utils/MessageBuilder.js')).default;

            // Services
            this.database = new Database(this);
            this.commandHandler = new CommandHandler(this);
            this.eventHandler = new EventHandler(this);
            this.messageHandler = new MessageHandler(this);
            this.pluginManager = new PluginManager(this);
            this.statistics = new Statistics(this);
            this.cacheManager = new CacheManager(this);
            this.securityManager = new SecurityManager(this);
            this.sessionManager = new SessionManager(this);
            this.pairingManager = new PairingManager(this);
            this.healthMonitor = new HealthMonitor(this);
            this.recovery = new BucyRecovery(this);
            this.formatter = new Formatter(this);
            this.helper = new Helper(this);
            this.validator = new Validator(this);
            this.converter = new Converter(this);
            this.messageBuilder = new MessageBuilder(this);

            // Initialize
            await this.database.initialize();
            await this.statistics.loadStats();
            await this.securityManager.initialize();
            await this.pluginManager.loadAllPlugins();
            await this.commandHandler.loadCommands();
            await this.pairingManager.loadPairingInfo();

            // Recovery
            this.recovery.start();

            this.initialized = true;
            this.logger.success('BUCY AI X initialized successfully');
            
        } catch (error) {
            const fallbackLogger = this.logger || console;
            fallbackLogger.error('Initialization failed:', error);
            throw error;
        }
        
        return this;
    }

    startMessageHandler() {
        if (this.messageHandler && typeof this.messageHandler.start === 'function') {
            this.messageHandler.start();
            this.logger?.info('Message handler started');
        }
    }

    stopMessageHandler() {
        if (this.messageHandler && typeof this.messageHandler.stop === 'function') {
            this.messageHandler.stop();
            this.logger?.info('Message handler stopped');
        }
    }

    async shutdown() {
        if (this.isShuttingDown) {
            this.logger?.debug('Shutdown already in progress');
            return;
        }

        this.isShuttingDown = true;
        const logger = this.logger || console;
        logger.info('Shutting down BUCY AI X...');
        this.isRunning = false;

        try {
            this.stopMessageHandler();

            if (this.statistics) {
                await this.statistics.saveStats();
            }

            if (this.database) {
                if (typeof this.database.saveAll === 'function') {
                    await this.database.saveAll();
                }
                if (typeof this.database.close === 'function') {
                    await this.database.close();
                }
            }

            if (this.sock) {
                try {
                    if (this.sock.ws && typeof this.sock.ws.close === 'function') {
                        this.sock.ws.close();
                    }
                    if (typeof this.sock.end === 'function') {
                        await this.sock.end();
                    }
                    if (this.sock.ev && typeof this.sock.ev.removeAllListeners === 'function') {
                        this.sock.ev.removeAllListeners();
                    }
                } catch (error) {
                    logger.error('Error closing socket:', error);
                }
                this.sock = null;
            }

            if (this.cacheManager && typeof this.cacheManager.clear === 'function') {
                this.cacheManager.clear();
            }

            this.emit('shutdown');
            logger.success('BUCY AI X shut down successfully');
            
        } catch (error) {
            logger.error('Shutdown error:', error);
            throw error;
        } finally {
            this.isShuttingDown = false;
        }
    }

    getStatus() {
        return {
            isRunning: this.isRunning,
            isConnected: !!this.sock,
            initialized: this.initialized,
            isShuttingDown: this.isShuttingDown,
            botNumber: this.botNumber,
            messageCount: this.messageCount,
            commandCount: this.commandCount,
            errorCount: this.errorCount,
            uptime: Math.floor((Date.now() - this.startTime) / 1000)
        };
    }
}

export default BucyXMaro;
