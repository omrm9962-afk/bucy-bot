// ================================================================
// FILE: Config/Messages.js
// ================================================================
// BUCY AI X - MESSAGES CONFIGURATION
// ================================================================

export default {
    system: {
        starting: '🔄 Starting BUCY AI X...',
        ready: '✅ BUCY AI X is ready!',
        shutdown: '🔴 Shutting down...',
        restart: '🔄 Restarting...',
        error: '❌ An error occurred. Please try again later.',
        unknown: '❌ Unknown command. Use .menu to see available commands.',
        cooldown: '⏳ Please wait {seconds} seconds before using this command again.',
        maintenance: '🔧 Bot is under maintenance. Please try again later.'
    },

    permission: {
        ownerOnly: '👑 This command is for bot owner only.',
        premiumOnly: '⭐ This command requires premium subscription.',
        groupOnly: '👥 This command can only be used in groups.',
        privateOnly: '📱 This command can only be used in private chat.',
        blacklisted: '🚫 You are blacklisted from using the bot.'
    },

    group: {
        welcome: '👋 Welcome @{name} to the group!\n\nPlease read the rules and enjoy your stay.',
        goodbye: '👋 Goodbye @{name}, we\'ll miss you!',
        antiLink: '🚫 @{name}, links are not allowed in this group!',
        antiSpam: '🚫 @{name} has been muted for spamming!',
        warn: '⚠️ @{name} has been warned ({warns}/{maxWarns})',
        kicked: '🚫 @{name} has been kicked for reaching {maxWarns} warns!'
    },

    connection: {
        connecting: '🔄 Connecting to WhatsApp...',
        connected: '✅ Connected successfully!',
        disconnected: '🔴 Disconnected. Reconnecting in {seconds} seconds...',
        loggedOut: '🔴 You have been logged out. Please re-pair.',
        pairingCode: '📱 Pairing Code: {code}',
        pairingQR: '📱 Scan this QR code with WhatsApp'
    },

    ai: {
        thinking: '🤖 Thinking...',
        response: '💡 AI Response:\n{response}',
        error: '❌ AI service is currently unavailable. Please try again later.',
        noQuestion: '🤖 Please provide a question.\nUsage: .ai <question>'
    },

    media: {
        downloading: '📥 Downloading...',
        processing: '⚙️ Processing...',
        complete: '✅ Download complete!',
        error: '❌ Failed to download. Please try again later.',
        noUrl: '📥 Please provide a valid URL.\nUsage: .youtube <url>'
    },

    premium: {
        added: '✅ Premium added to user: {userId}',
        removed: '🗑️ Premium removed from user: {userId}',
        already: '⚠️ User is already premium.',
        notFound: '❌ User not found in premium list.',
        list: '👑 Premium Users List ({count})\n{list}',
        status: '🔍 Premium Status\nUser: {userId}\nStatus: {status}'
    },

    stats: {
        title: '📊 Bot Statistics',
        users: '👥 Users: {count}',
        groups: '👤 Groups: {count}',
        commands: '⚡ Commands: {count}',
        messages: '💬 Messages: {count}',
        errors: '❌ Errors: {count}',
        uptime: '⏱️ Uptime: {time}',
        memory: '💻 Memory: {memory}MB',
        pid: '🆔 PID: {pid}'
    },

    menu: {
        title: '📋 BUCY AI X MENU',
        footer: '🤖 {botName} v{version}',
        category: '{emoji} {category}',
        command: '▸ .{name} {aliases}{badges}',
        total: '📊 Total: {count} commands'
    }
};