// ================================================================
// FILE: Config/Debug.js
// ================================================================
// BUCY AI X - DEBUG CONFIGURATION
// ================================================================

export default {
    enabled: true,
    showStack: true,
    showImports: true,
    showBootSteps: true,
    showTiming: true,
    logFile: './logs/startup-debug.log',
    maxLogSize: 10485760 // 10MB
};