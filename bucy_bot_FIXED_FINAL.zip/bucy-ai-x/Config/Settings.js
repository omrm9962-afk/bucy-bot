// ================================================================
// FILE: Config/Settings.js
// ================================================================
// BUCY AI X - SETTINGS CONFIGURATION
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Settings {
    constructor() {
        this.settingsPath = path.join(__dirname, '../Data/settings.json');
        this.defaultSettings = {
            bot: {
                name: 'BUCY AI X',
                version: '2.0.0',
                author: 'MARO',
                prefix: '.',
                status: 'online',
                language: 'ar',
                timezone: 'Africa/Cairo'
            },
            groups: {
                welcome: true,
                goodbye: true,
                antiLink: false,
                antiSpam: true,
                antiFake: false,
                antiBot: false,
                maxWarns: 3,
                autoRole: false
            },
            security: {
                rateLimit: { enabled: true, maxRequests: 5, window: 5000 },
                floodProtection: { enabled: true, maxMessages: 5, window: 10000 },
                blacklist: []
            },
            ai: {
                enabled: true,
                provider: 'openai',
                model: 'gpt-3.5-turbo',
                maxTokens: 1000,
                temperature: 0.7
            },
            media: {
                maxSize: 50,
                allowedTypes: ['image', 'video', 'audio', 'document'],
                tempPath: './Temp'
            },
            logging: {
                enabled: true,
                level: 'info',
                console: true,
                file: true,
                path: './Logs'
            },
            backup: {
                enabled: true,
                interval: 21600000,
                maxBackups: 7,
                path: './Backups'
            },
            dashboard: {
                enabled: true,
                port: 3000,
                host: '0.0.0.0',
                apiKey: null
            },
            telegram: {
                enabled: true,
                token: process.env.TELEGRAM_BOT_TOKEN || '',
                ownerId: process.env.OWNER_ID || '7697500717'
            }
        };
        this.settings = { ...this.defaultSettings };
    }

    async load() {
        try {
            if (await fs.pathExists(this.settingsPath)) {
                const data = await fs.readJson(this.settingsPath);
                this.settings = { ...this.defaultSettings, ...data };
            } else {
                await this.save();
            }
            return this.settings;
        } catch (error) {
            this.settings = { ...this.defaultSettings };
            return this.settings;
        }
    }

    async save() {
        try {
            await fs.ensureDir(path.dirname(this.settingsPath));
            await fs.writeJson(this.settingsPath, this.settings, { spaces: 2 });
            return true;
        } catch (error) {
            return false;
        }
    }

    get(key) {
        const keys = key.split('.');
        let value = this.settings;
        for (const k of keys) {
            if (value && typeof value === 'object' && k in value) {
                value = value[k];
            } else {
                return undefined;
            }
        }
        return value;
    }

    async set(key, value) {
        const keys = key.split('.');
        let target = this.settings;
        for (let i = 0; i < keys.length - 1; i++) {
            if (!(keys[i] in target)) {
                target[keys[i]] = {};
            }
            target = target[keys[i]];
        }
        target[keys[keys.length - 1]] = value;
        await this.save();
        return value;
    }

    async reset() {
        this.settings = { ...this.defaultSettings };
        await this.save();
        return this.settings;
    }

    getAll() {
        return this.settings;
    }
}

export default Settings;