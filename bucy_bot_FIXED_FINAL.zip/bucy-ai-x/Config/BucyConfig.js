// ================================================================
// FILE: Config/BucyConfig.js (FIXED)
// ================================================================
// BUCY AI X - CONFIGURATION
// ================================================================

export default {
    name: process.env.BOT_NAME || 'BUCY AI X',
    version: '2.0.0',
    author: 'MARO',
    // ✅ FIX: Use env var for owner number - set OWNER_NUMBER in .env
    prefix: process.env.BOT_PREFIX || '.',
    
    owners: (process.env.OWNER_NUMBER || '201234567890').split(',').map(n => n.trim()),
    
    database: {
        path: './Database',
        backupInterval: 3600000
    },
    
    security: {
        rateLimit: {
            enabled: true,
            maxRequests: 5,
            window: 5000
        }
    },
    
    logging: {
        enabled: true,
        level: 'info',
        console: true,
        file: true,
        path: './Logs'
    },
    
    backup: {
        enabled: true,
        interval: 21600000,
        maxBackups: 7,
        path: './Backups'
    },
    
    messages: {
        error: '❌ An error occurred. Please try again later.',
        ownerOnly: '👑 This command is for bot owner only.',
        premiumOnly: '⭐ This command requires premium subscription.',
        groupOnly: '👥 This command can only be used in groups.',
        privateOnly: '📱 This command can only be used in private chat.'
    }
};
