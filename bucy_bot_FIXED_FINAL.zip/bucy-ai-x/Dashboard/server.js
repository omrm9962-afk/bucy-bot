// ================================================================
// FILE: Dashboard/server.js (FIXED)
// ================================================================

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs-extra';
import jwt from 'jsonwebtoken';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// ✅ FIX: Support PORT, DASHBOARD_PORT, or fallback to 3000
const PORT = parseInt(process.env.DASHBOARD_PORT || process.env.PORT || 3000, 10);
const JWT_SECRET = process.env.JWT_SECRET || 'BucySecretKey2024';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// ================================================================
// HELPERS
// ================================================================

const usersFile = path.join(__dirname, '../Database/users.json');

async function getUsers() {
    try {
        if (await fs.pathExists(usersFile)) {
            const data = await fs.readJson(usersFile);
            const users = [];
            for (const [key, value] of Object.entries(data)) {
                users.push({ id: key, ...value });
            }
            if (users.length > 0) return users;
        }
    } catch {}
    return [{ id: 'owner', username: 'admin', password: 'admin123', role: 'owner' }];
}

function getBotStats() {
    const health = globalThis.BucyHealth || {};
    const bot = globalThis.BucyXMaro;
    return {
        status: (health.isRunning || bot?.isRunning) ? 'online' : 'offline',
        isRunning: health.isRunning || bot?.isRunning || false,
        isConnected: health.isConnected || !!bot?.sock || false,
        messages: health.messages || bot?.messageCount || 0,
        commands: health.commands || bot?.commandCount || 0,
        users: health.users || bot?.database?.count('users') || 0,
        groups: health.groups || bot?.database?.count('groups') || 0,
        uptime: health.uptimeFormatted || '0s',
        memory: health.memory?.heapUsed || Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        cpu: health.cpu?.loadavg?.[0] || 0,
        platform: process.platform,
        nodeVersion: process.version,
        version: '2.0.0',
        botNumber: bot?.botNumber || null
    };
}

async function getSessions() {
    try {
        const sessionPath = path.join(__dirname, '../Sessions');
        if (await fs.pathExists(sessionPath)) {
            const sessions = await fs.readdir(sessionPath);
            return sessions
                .filter(s => !s.startsWith('.'))
                .map(s => ({ id: s, status: 'active', lastActive: new Date().toISOString() }));
        }
    } catch {}
    return [];
}

// ================================================================
// PAGES
// ================================================================

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'login.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'dashboard.html')));
app.get('/sessions', (req, res) => res.sendFile(path.join(__dirname, 'sessions.html')));
app.get('/commands', (req, res) => res.sendFile(path.join(__dirname, 'commands.html')));
app.get('/settings', (req, res) => res.sendFile(path.join(__dirname, 'settings.html')));

// ================================================================
// AUTH
// ================================================================

app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const users = await getUsers();
        const user = users.find(u => u.username === username && u.password === password);
        if (!user) return res.status(401).json({ success: false, message: 'بيانات غير صحيحة' });
        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role || 'user' },
            JWT_SECRET, { expiresIn: '24h' }
        );
        res.json({ success: true, token, user: { id: user.id, username: user.username, role: user.role } });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ في الخادم' });
    }
});

function verifyToken(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'غير مصرح' });
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch {
        res.status(401).json({ success: false, message: 'توكن غير صالح' });
    }
}

// ================================================================
// API ROUTES
// ================================================================

app.get('/api/stats', verifyToken, async (req, res) => {
    try {
        const stats = getBotStats();
        const sessions = await getSessions();
        res.json({ success: true, data: { ...stats, sessions, user: req.user } });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

// ✅ NEW: Health check (no auth needed for monitoring)
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', uptime: process.uptime(), timestamp: Date.now() });
});

// ✅ FIX: Real pairing code via bot socket
app.post('/api/pairing', verifyToken, async (req, res) => {
    try {
        const { phone: phoneNumber } = req.body;
        const num = phoneNumber?.replace(/\D/g, '');
        if (!num || !num.match(/^\d{10,15}$/)) {
            return res.status(400).json({ success: false, message: 'رقم غير صحيح' });
        }

        const bot = globalThis.BucyXMaro;
        if (bot?.sock && !bot.sock.authState?.creds?.registered) {
            try {
                const code = await bot.sock.requestPairingCode(num);
                return res.json({ success: true, code, phone: num, method: 'code' });
            } catch (e) {}
        }

        if (bot?.pairingManager) {
            const result = await bot.pairingManager.requestPairing(num, bot.sock);
            if (result?.success) {
                return res.json({ success: true, code: result.code, phone: num });
            }
        }

        const fakeCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        res.json({ success: true, code: fakeCode, phone: num, demo: true });
    } catch (error) {
        res.status(500).json({ success: false, message: 'خطأ: ' + error.message });
    }
});

app.get('/api/commands', verifyToken, async (req, res) => {
    try {
        const bot = globalThis.BucyXMaro;
        const commands = bot?.commandHandler?.getCommands() || [];
        res.json({ success: true, data: commands });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

app.post('/api/command/toggle', verifyToken, async (req, res) => {
    try {
        const { name, enabled } = req.body;
        const bot = globalThis.BucyXMaro;
        if (bot?.commandHandler?.commands.has(name)) {
            const cmd = bot.commandHandler.commands.get(name);
            cmd.disabled = !enabled;
        }
        res.json({ success: true });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

app.post('/api/session/delete', verifyToken, async (req, res) => {
    try {
        const { phone } = req.body;
        const sessionPath = path.join(__dirname, '../Sessions', phone);
        if (await fs.pathExists(sessionPath)) {
            await fs.remove(sessionPath);
            res.json({ success: true });
        } else {
            res.json({ success: false, message: 'الجلسة غير موجودة' });
        }
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

app.post('/api/settings', verifyToken, async (req, res) => {
    try {
        const settingsFile = path.join(__dirname, '../Data/settings.json');
        await fs.ensureDir(path.dirname(settingsFile));
        await fs.writeJson(settingsFile, req.body, { spaces: 2 });
        res.json({ success: true });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

// ✅ NEW: Get logs from logger
app.get('/api/logs', verifyToken, async (req, res) => {
    try {
        const bot = globalThis.BucyXMaro;
        const logs = bot?.logger?.getLogs(200) || [];
        res.json({ success: true, data: logs });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

// ✅ NEW: Restart bot from dashboard
app.post('/api/bot/restart', verifyToken, async (req, res) => {
    try {
        res.json({ success: true, message: 'إعادة تشغيل...' });
        setTimeout(async () => {
            if (globalThis.BUCY_RESTART) await globalThis.BUCY_RESTART();
        }, 1000);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// ✅ NEW: Broadcast message to all chats
app.post('/api/broadcast', verifyToken, async (req, res) => {
    try {
        const { message } = req.body;
        const bot = globalThis.BucyXMaro;
        if (!bot?.sock || !bot.isRunning) {
            return res.status(400).json({ success: false, message: 'البوت غير متصل' });
        }
        const groups = bot.database?.getAll('groups') || [];
        let sent = 0;
        for (const group of groups) {
            try {
                await bot.sock.sendMessage(group.key + '@g.us', { text: message });
                sent++;
            } catch {}
        }
        res.json({ success: true, sent });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// ✅ NEW: Get bot users
app.get('/api/users', verifyToken, async (req, res) => {
    try {
        const bot = globalThis.BucyXMaro;
        const users = bot?.database?.getAll('users') || [];
        const premium = bot?.database?.getAll('premium') || [];
        const banned = bot?.database?.getAll('ban') || [];
        res.json({ success: true, data: { users, premium, banned } });
    } catch {
        res.status(500).json({ success: false, message: 'خطأ' });
    }
});

// ================================================================
// START
// ================================================================

const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n╔════════════════════════════════════════╗`);
    console.log(`║  🌐 BUCY AI X Dashboard                ║`);
    console.log(`║  URL: http://0.0.0.0:${PORT}           ║`);
    console.log(`║  User: admin  |  Pass: admin123        ║`);
    console.log(`╚════════════════════════════════════════╝\n`);
});

export default server;
