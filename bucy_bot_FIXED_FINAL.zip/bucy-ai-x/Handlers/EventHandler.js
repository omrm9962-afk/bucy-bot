// ================================================================
// FILE: Handlers/EventHandler.js
// ================================================================
// BUCY AI X - EVENT HANDLING SYSTEM
// ================================================================

class EventHandler {
    constructor(bucy) {
        this.bucy = bucy;
        this.events = new Map();
    }

    async loadEvents() {
        this.bucy.logger?.info('Loading events...');
        // Events will be loaded from Events folder
        this.bucy.logger?.success('Events loaded');
    }

    async handleGroupUpdate(update) {
        try {
            const { id, participants, action } = update;
            this.bucy.logger?.info(`Group update: ${action} in ${id}`);
            
            // Handle welcome/goodbye events
            if (action === 'add') {
                for (const participant of participants) {
                    await this.handleWelcome(id, participant);
                }
            }
            
            if (action === 'remove') {
                for (const participant of participants) {
                    await this.handleGoodbye(id, participant);
                }
            }
        } catch (error) {
            this.bucy.logger?.error('Error handling group update:', error);
        }
    }

    async handleWelcome(groupId, participant) {
        try {
            const settings = this.bucy.settings?.get('groups') || {};
            if (!settings.welcome) return;

            const name = participant.split('@')[0];
            const welcomeText = this.bucy.messageService?.get('group.welcome', { name }) || 
                `👋 Welcome @${name} to the group!\n\nPlease read the rules and enjoy your stay.`;

            await this.bucy.sendMessage(groupId, {
                text: welcomeText,
                mentions: [participant]
            });
        } catch (error) {
            this.bucy.logger?.error('Welcome event error:', error);
        }
    }

    async handleGoodbye(groupId, participant) {
        try {
            const settings = this.bucy.settings?.get('groups') || {};
            if (!settings.goodbye) return;

            const name = participant.split('@')[0];
            const goodbyeText = this.bucy.messageService?.get('group.goodbye', { name }) ||
                `👋 Goodbye @${name}, we'll miss you!`;

            await this.bucy.sendMessage(groupId, {
                text: goodbyeText,
                mentions: [participant]
            });
        } catch (error) {
            this.bucy.logger?.error('Goodbye event error:', error);
        }
    }
}

export default EventHandler;