// ================================================================
// FILE: Handlers/MessageHandler.js (FIXED - with Auto Replies)
// ================================================================

import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs-extra';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const AUTO_REPLIES = {
    "السلام عليكم": "وعليكم السلام ورحمة الله وبركاته 🌸",
    "هاي": "هاي 👋، عامل إيه؟",
    "ابوت": "*عايز اي انجز🐦*",
    "ابحبك": "*وأنا كمان بحبك متيجي🐦💋*",
    "اصباح الخير": "صباح النور والورد 🌞🌹",
    "مسااء الخير": "مساء الفل والياسمين 🌙✨",
    "بوات عاق": "*كسمك ياه متشتمش البوت ي عاااق 🐦*",
    "ياب": "*استرجل وقول نعم 🐦*",
    "نااعم": "*حد ناداك 🐦*",
    "ااحا": "`احــــا عــلـــي احــــتـــــك 🌸`",
    "ابان قحبه": "*اظـن م ف قحـبه هنا غير امك 🐦*",
    "قحابه": "*امك القحبه طير يعاق 🐦*",
    "عامال اي": "*انت مالك🐦*",
    "كاويس الحمدلله": "*مش بسال عن حالك بكسف حضرتك🐦*",
    "بوتا بضان": "*مفيش ابضن منك هنا يلا يعاق🐦*",
    "ةبضان": "*خرم طيزك حمضان ناكك محمد رمضان🐦*",
    "اعاملك شاي": "*اقـلع*",
    "لاي": "*هعلمك ازاي تعمل شاي🐦*",
    "ماتناك": "*بنيك امك هناك🐦*",
    "الوف": "*شكلك شاذ🐦*",
    "انلت": "*تبا لك غبي بحق*🐦",
    "ا🙂": "*بـص بـعـيد🙂*",
    "اسلام عليكم": "*وعليكم السلام ورحمة الله وبركاتة*",
    "حلب": "*حبك برص وعشره خرس🐦*",
    "بلف": "*ايوا بق بف وحب ومنيكه🐦*",
    "كاسمك": "*كسمينك يخول🐦*",
    "ي ابوت": "*قول يبن المتناكه عايز اي🐦*"
};

const MARO_KEYWORDS = ["مارو", "عمر", "ادريان"];
const MARO_EMOJIS = ["⚡", "🔥", "💥", "🩶", "👄", "💋", "♥", "🐦", "🗿", "💙", "🙂"];

class MessageHandler {
    constructor(bucy) {
        this.bucy = bucy;
        this.isRunning = false;
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        this.bucy.logger?.info('Message handler started');
    }

    stop() {
        if (!this.isRunning) return;
        this.isRunning = false;
        this.bucy.logger?.info('Message handler stopped');
    }

    async handleMessages(sock, m) {
        if (!this.isRunning) return;
        try {
            if (!m.messages || m.messages.length === 0) return;
            const msg = m.messages[0];
            if (!msg.message) return;

            const fromMe = msg.key.fromMe;
            const messageText = this.extractText(msg);

            this.bucy.messageCount = (this.bucy.messageCount || 0) + 1;

            if (fromMe) return;

            msg.sender = msg.key.participant || msg.key.remoteJid;
            msg.chat = msg.key.remoteJid;
            msg.isGroup = msg.key.remoteJid?.endsWith('@g.us') || false;
            msg.isOwner = this.isOwner(msg.sender);
            msg.isAdmin = msg.isGroup ? await this.isAdmin(msg.sender, msg.key.remoteJid) : false;
            msg.isPremium = await this.isPremium(msg.sender);
            msg.isElite = await this.isElite(msg.sender);
            msg.reply = async (text, options = {}) => {
                return await sock.sendMessage(msg.key.remoteJid, { text }, { ...options, quoted: msg });
            };
            msg.react = async (emoji) => {
                return await sock.sendMessage(msg.key.remoteJid, { react: { text: emoji, key: msg.key } });
            };

            if (msg.sender && !msg.isGroup) {
                this.bucy.database?.set('users', msg.sender, {
                    name: msg.pushName || 'Unknown',
                    lastSeen: Date.now()
                }).catch(() => {});
            }

            if (msg.isGroup) {
                this.bucy.database?.set('groups', msg.key.remoteJid, {
                    lastActivity: Date.now()
                }).catch(() => {});
            }

            // ================================================================
            // الردود التلقائية
            // ================================================================
            if (messageText) {
                const normalized = messageText.trim().toLowerCase();

                if (AUTO_REPLIES[normalized]) {
                    await sock.sendMessage(
                        msg.key.remoteJid,
                        { text: AUTO_REPLIES[normalized] },
                        { quoted: msg }
                    ).catch(() => {});
                    return;
                }

                if (MARO_KEYWORDS.some(kw => normalized.includes(kw))) {
                    try {
                        const randomEmoji = MARO_EMOJIS[Math.floor(Math.random() * MARO_EMOJIS.length)];
                        await sock.sendMessage(msg.key.remoteJid, {
                            react: { text: randomEmoji, key: msg.key }
                        }).catch(() => {});

                        const thumbPath = path.join(__dirname, '..', 'مارو', 'صورة.jpg');
                        let thumbBuffer = Buffer.alloc(10);
                        if (fs.existsSync(thumbPath)) {
                            thumbBuffer = fs.readFileSync(thumbPath);
                        }

                        const audioPath = path.join(__dirname, '..', 'مارو', 'ahh.mp3');
                        const groupLink = "https://chat.whatsapp.com/HapOsDZk6rS8GL5Qo7cdTq";

                        if (fs.existsSync(audioPath)) {
                            await sock.sendMessage(
                                msg.key.remoteJid,
                                {
                                    audio: { url: audioPath },
                                    mimetype: "audio/mpeg",
                                    ptt: false,
                                    contextInfo: {
                                        externalAdReply: {
                                            title: "𝒀𝑨𝑴𝑨𝑻𝑶 𓂀",
                                            body: "𝑭𝑼𝑪𝑲 𝒀𝑶𝑼",
                                            mediaType: 1,
                                            thumbnail: thumbBuffer,
                                            showAdAttribution: true,
                                            sourceUrl: groupLink
                                        }
                                    }
                                },
                                { quoted: msg }
                            ).catch(() => {});
                        }
                    } catch (err) {
                        this.bucy.logger?.error('خطأ في تفاعل مارو:', err);
                    }
                    return;
                }
            }

            // ================================================================
            // معالجة الأوامر
            // ================================================================
            await this.bucy.commandHandler.handleMessage(sock, msg);

        } catch (error) {
            this.bucy.logger?.error('Error handling messages:', error);
            this.bucy.errorCount = (this.bucy.errorCount || 0) + 1;
        }
    }

    extractText(msg) {
        return msg.message?.conversation ||
               msg.message?.extendedTextMessage?.text ||
               msg.message?.imageMessage?.caption ||
               msg.message?.videoMessage?.caption ||
               msg.message?.documentMessage?.caption ||
               msg.message?.buttonsResponseMessage?.selectedButtonId ||
               msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId || '';
    }

    isOwner(sender) {
        const owners = this.bucy.config?.owners || ['201234567890'];
        const number = sender?.split('@')[0] || sender;
        return owners.includes(number) || owners.includes(sender);
    }

    async isAdmin(sender, groupId) {
        try {
            if (!groupId?.endsWith('@g.us')) return false;
            const metadata = await this.bucy.sock?.groupMetadata(groupId);
            if (!metadata) return false;
            const participant = metadata.participants.find(p => p.id === sender);
            return participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch { return false; }
    }

    async isPremium(sender) {
        try { return this.bucy.database?.exists('premium', sender) || false; }
        catch { return false; }
    }

    async isElite(sender) {
        try { return this.bucy.database?.exists('elite', sender) || false; }
        catch { return false; }
    }
}

export default MessageHandler;
