// ================================================================
// FILE: Handlers/CommandHandler.js
// ================================================================
// BUCY AI X - COMMAND HANDLER
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class CommandHandler {
    constructor(bucy) {
        this.bucy = bucy;
        this.commands = new Map();
        this.aliases = new Map();
        this.cooldowns = new Map();
        this.commandsPath = path.join(__dirname, '../commands');
        this.isLoaded = false;
    }

    // ================================================================
    // ✅ SAFE LOGGER HELPER
    // ================================================================

    log(message, type = 'info') {
        if (this.bucy && this.bucy.logger) {
            if (type === 'info') this.bucy.logger.info(message);
            else if (type === 'success') this.bucy.logger.success(message);
            else if (type === 'warn') this.bucy.logger.warn(message);
            else if (type === 'error') this.bucy.logger.error(message);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
    }

    // ================================================================
    // 📂 LOAD COMMANDS
    // ================================================================

    async loadCommands() {
        try {
            this.log('📂 Loading commands...', 'info');
            
            // ✅ اتأكد إن مجلد commands موجود
            await fs.ensureDir(this.commandsPath);

            const files = await fs.readdir(this.commandsPath);
            const commandFiles = files.filter(file => file.endsWith('.js'));

            this.log(`📁 Found ${commandFiles.length} command files`, 'info');

            let loaded = 0;
            let failed = 0;

            for (const file of commandFiles) {
                try {
                    const filePath = path.join(this.commandsPath, file);
                    const timestamp = Date.now();
                    
                    // ✅ استيراد الملف
                    const { default: command } = await import(`file://${filePath}?t=${timestamp}`);
                    
                    if (this.validateCommand(command)) {
                        this.registerCommand(command);
                        loaded++;
                        this.log(`✅ Loaded: ${command.command}`, 'success');
                    } else {
                        failed++;
                        this.log(`⚠️ Invalid command: ${file}`, 'warn');
                    }
                } catch (error) {
                    failed++;
                    this.log(`❌ Failed to load ${file}: ${error.message}`, 'error');
                }
            }

            this.isLoaded = true;
            this.log(`✅ Loaded ${loaded} commands (${failed} failed)`, 'success');

        } catch (error) {
            this.log(`❌ Failed to load commands: ${error.message}`, 'error');
            throw error;
        }
    }

    // ================================================================
    // ✅ VALIDATE COMMAND
    // ================================================================

    validateCommand(command) {
        if (!command.command) {
            this.log('⚠️ Command missing command name', 'warn');
            return false;
        }

        if (typeof command.execute !== 'function') {
            this.log(`⚠️ Command ${command.command} missing execute function`, 'warn');
            return false;
        }

        // ✅ إعداد الخصائص الافتراضية
        command.category = command.category || 'General';
        command.description = command.description || 'No description';
        command.aliases = command.aliases || [];
        command.usage = command.usage || `.${command.command}`;
        command.owner = command.owner || false;
        command.group = command.group || false;
        command.admin = command.admin || false;
        command.premium = command.premium || false;
        command.elite = command.elite || false;
        command.cooldown = command.cooldown || 0;

        return true;
    }

    // ================================================================
    // 📌 REGISTER COMMAND
    // ================================================================

    registerCommand(command) {
        // تسجيل الأمر الرئيسي
        this.commands.set(command.command, command);

        // تسجيل الـ Aliases
        if (command.aliases && Array.isArray(command.aliases)) {
            for (const alias of command.aliases) {
                this.aliases.set(alias, command.command);
            }
        }
    }

    // ================================================================
    // 📨 HANDLE MESSAGE
    // ================================================================

    async handleMessage(sock, msg) {
        try {
            // ✅ استخراج النص
            const messageText = msg.message?.conversation ||
                              msg.message?.extendedTextMessage?.text ||
                              msg.message?.imageMessage?.caption ||
                              msg.message?.videoMessage?.caption || '';

            if (!messageText) return;

            // ✅ التحقق من البادئة
            const prefix = this.bucy?.botPrefix || '.';
            if (!messageText.startsWith(prefix)) return;

            // ✅ استخراج الأمر
            const args = messageText.slice(prefix.length).trim().split(/\s+/);
            const commandName = args.shift()?.toLowerCase();
            
            if (!commandName) return;

            // ✅ البحث عن الأمر
            let command = this.commands.get(commandName);
            if (!command) {
                const aliasTarget = this.aliases.get(commandName);
                if (aliasTarget) {
                    command = this.commands.get(aliasTarget);
                }
            }

            if (!command) {
                this.log(`⚠️ Unknown command: ${commandName}`, 'warn');
                return;
            }

            // ✅ إنشاء السياق
            const context = this.createContext(sock, msg, args, command);

            // ✅ التحقق من الصلاحيات
            if (!await this.checkPermissions(context)) return;

            // ✅ التحقق من الـ Cooldown
            if (!await this.checkCooldown(context)) return;

            this.log(`⚡ Executing: ${command.command} [${command.category}]`, 'info');

            try {
                await command.execute(context);
                if (this.bucy) {
                    this.bucy.commandCount = (this.bucy.commandCount || 0) + 1;
                }
            } catch (error) {
                this.log(`❌ Command ${command.command} failed: ${error.message}`, 'error');
                await context.reply(`❌ Error: ${error.message || 'Unknown error'}`);
            }

        } catch (error) {
            this.log(`❌ Error handling message: ${error.message}`, 'error');
        }
    }

    // ================================================================
    // 📦 CREATE CONTEXT
    // ================================================================

    createContext(sock, msg, args, command) {
        const sender = msg.key.participant || msg.key.remoteJid;
        return {
            sock,
            msg,
            args,
            command,
            bucy: this.bucy,
            sender: sender,
            chat: msg.key.remoteJid,
            isGroup: msg.key.remoteJid.endsWith('@g.us'),
            isOwner: this.isOwner(sender),
            isAdmin: this.isAdmin(sender, msg.key.remoteJid),
            isPremium: this.isPremium(sender),
            isElite: this.isElite(sender),
            reply: async (text, options = {}) => {
                return await sock.sendMessage(msg.key.remoteJid, { text }, { ...options, quoted: msg });
            },
            react: async (emoji) => {
                return await sock.sendMessage(msg.key.remoteJid, { react: { text: emoji, key: msg.key } });
            },
            send: async (content, options = {}) => {
                return await sock.sendMessage(msg.key.remoteJid, content, options);
            },
            db: this.bucy?.database,
            cache: this.bucy?.cacheManager,
            logger: this.bucy?.logger,
            config: this.bucy?.config,
            settings: this.bucy?.settings,
            messageService: this.bucy?.messageService
        };
    }

    // ================================================================
    // 🔐 CHECK PERMISSIONS
    // ================================================================

    async checkPermissions(context) {
        const command = context.command;
        const sender = context.sender;

        if (command.owner && !context.isOwner) {
            await context.reply('👑 This command is for bot owner only.');
            return false;
        }

        if (command.premium && !context.isPremium) {
            await context.reply('⭐ This command requires premium subscription.');
            return false;
        }

        if (command.elite && !context.isElite) {
            await context.reply('🌟 This command is for elite members only.');
            return false;
        }

        if (command.group && !context.isGroup) {
            await context.reply('👥 This command can only be used in groups.');
            return false;
        }

        if (command.admin && !context.isAdmin) {
            await context.reply('🛡️ This command requires admin privileges.');
            return false;
        }

        if (command.private && context.isGroup) {
            await context.reply('📱 This command can only be used in private chat.');
            return false;
        }

        if (await this.isBlacklisted(sender)) {
            await context.reply('🚫 You are blacklisted from using the bot.');
            return false;
        }

        return true;
    }

    // ================================================================
    // ⏳ CHECK COOLDOWN
    // ================================================================

    async checkCooldown(context) {
        const command = context.command;
        const cooldown = command.cooldown || 0;
        
        if (cooldown === 0) return true;

        const key = `${context.sender}_${command.command}`;
        const now = Date.now();
        const cooldownTime = this.cooldowns.get(key);

        if (cooldownTime && now < cooldownTime) {
            const remaining = Math.ceil((cooldownTime - now) / 1000);
            await context.reply(`⏳ Please wait ${remaining} seconds.`);
            return false;
        }

        this.cooldowns.set(key, now + (cooldown * 1000));
        setTimeout(() => this.cooldowns.delete(key), cooldown * 1000);
        return true;
    }

    // ================================================================
    // 👑 HELPERS
    // ================================================================

    isOwner(sender) {
        const owners = this.bucy?.config?.owners || ['201234567890'];
        const number = sender?.split('@')[0] || sender;
        return owners.includes(number) || owners.includes(sender);
    }

    async isAdmin(sender, groupId) {
        try {
            if (!groupId || !groupId.endsWith('@g.us')) return false;
            if (!this.bucy || !this.bucy.sock) return false;
            const metadata = await this.bucy.sock.groupMetadata(groupId);
            if (!metadata) return false;
            const participant = metadata.participants.find(p => p.id === sender);
            return participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch {
            return false;
        }
    }

    async isPremium(sender) {
        try {
            return this.bucy?.database?.exists('premium', sender) || false;
        } catch {
            return false;
        }
    }

    async isElite(sender) {
        try {
            return this.bucy?.database?.exists('elite', sender) || false;
        } catch {
            return false;
        }
    }

    async isBlacklisted(sender) {
        try {
            return this.bucy?.database?.exists('ban', sender) || false;
        } catch {
            return false;
        }
    }

    // ================================================================
    // 📋 GET COMMANDS
    // ================================================================

    getCommands() {
        const list = [];
        for (const [name, command] of this.commands) {
            list.push({
                name: name,
                command: command.command,
                category: command.category || 'General',
                description: command.description || 'No description',
                aliases: command.aliases || [],
                usage: command.usage || `.${name}`,
                owner: command.owner || false,
                group: command.group || false,
                admin: command.admin || false,
                premium: command.premium || false,
                elite: command.elite || false,
                cooldown: command.cooldown || 0
            });
        }
        return list;
    }

    getCommandsByCategory(category) {
        return this.getCommands().filter(cmd => cmd.category === category);
    }

    getCategories() {
        const categories = new Set();
        for (const [, command] of this.commands) {
            categories.add(command.category || 'General');
        }
        return Array.from(categories);
    }
}

export default CommandHandler;