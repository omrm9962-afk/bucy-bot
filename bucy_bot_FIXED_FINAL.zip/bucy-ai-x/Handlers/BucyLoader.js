// ================================================================
// FILE: Handlers/BucyLoader.js
// ================================================================
// BUCY AI X - COMMAND LOADER (FIXED)
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import chokidar from 'chokidar';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class BucyLoader {
    constructor(bucy) {
        this.bucy = bucy;
        this.commandsPath = path.join(__dirname, '../commands');
        this.watcher = null;
        this.isWatching = false;
        this.loadedCommands = new Map();
        this.loadedFiles = new Set();
        this.loadingLock = false;
        this.fileTimestamps = new Map();
    }

    /**
     * تحميل جميع الأوامر (مع منع التحميل المكرر)
     */
    async loadAll() {
        if (this.loadingLock) {
            this.bucy.logger?.warn('⚠️ Loading already in progress');
            return;
        }

        this.loadingLock = true;

        try {
            this.bucy.logger?.info('📂 BucyLoader: Loading commands...');
            await fs.ensureDir(this.commandsPath);

            const files = await fs.readdir(this.commandsPath);
            const commandFiles = files.filter(file => file.endsWith('.js'));

            let loaded = 0;
            let failed = 0;

            for (const file of commandFiles) {
                try {
                    const isValid = await this.validateFile(file);
                    if (!isValid) {
                        failed++;
                        continue;
                    }
                    await this.loadFile(file);
                    loaded++;
                } catch (error) {
                    this.bucy.logger?.error(`❌ Failed to load ${file}:`, error);
                    failed++;
                }
            }

            this.bucy.logger?.success(`✅ BucyLoader: Loaded ${loaded} commands (${failed} failed)`);
            return loaded;

        } finally {
            this.loadingLock = false;
        }
    }

    /**
     * التحقق من صحة الملف (مع منع التحميل المكرر)
     */
    async validateFile(file) {
        const filePath = path.join(this.commandsPath, file);
        
        // ✅ التحقق من وجود الملف
        if (!await fs.pathExists(filePath)) {
            this.bucy.logger?.warn(`⚠️ File not found: ${file}`);
            return false;
        }

        // ✅ التحقق من عدم التحميل المكرر
        if (this.loadedFiles.has(file)) {
            const timestamp = this.fileTimestamps.get(file);
            const stats = await fs.stat(filePath);
            if (timestamp && stats.mtimeMs === timestamp) {
                this.bucy.logger?.warn(`⚠️ File already loaded: ${file}`);
                return false;
            }
        }

        return true;
    }

    /**
     * تحميل ملف واحد (مع منع التحميل المكرر)
     */
    async loadFile(file) {
        const filePath = path.join(this.commandsPath, file);
        
        // ✅ منع التحميل المكرر
        if (this.loadedFiles.has(file)) {
            // ✅ إزالة الأمر القديم
            for (const [cmd, data] of this.loadedCommands) {
                if (data.file === file) {
                    this.loadedCommands.delete(cmd);
                }
            }
            this.loadedFiles.delete(file);
        }

        try {
            // ✅ Dynamic Import مع Timestamp لمنع Cache
            const timestamp = Date.now();
            const { default: command } = await import(`file://${filePath}?t=${timestamp}`);
            
            // ✅ التحقق من صحة الأمر
            if (!this.validateCommand(command)) {
                this.bucy.logger?.warn(`⚠️ Invalid command in ${file}`);
                return;
            }

            // ✅ تخزين الأمر
            this.loadedCommands.set(command.command, { ...command, file });
            this.loadedFiles.add(file);
            
            // ✅ حفظ Timestamp
            const stats = await fs.stat(filePath);
            this.fileTimestamps.set(file, stats.mtimeMs);

            // ✅ تسجيل الأمر في الـ Handler
            if (this.bucy.commandHandler) {
                this.bucy.commandHandler.registerCommand(command);
            }

            this.bucy.logger?.info(`📌 BucyLoader: Loaded ${command.command} from ${file}`);

        } catch (error) {
            this.bucy.logger?.error(`❌ Failed to load ${file}:`, error);
            throw error;
        }
    }

    /**
     * التحقق من صحة الأمر
     */
    validateCommand(command) {
        if (!command.command) {
            this.bucy.logger?.warn('⚠️ Command missing command name');
            return false;
        }

        if (typeof command.execute !== 'function') {
            this.bucy.logger?.warn(`⚠️ Command ${command.command} missing execute function`);
            return false;
        }

        // ✅ إعداد الخصائص الافتراضية
        command.category = command.category || 'General';
        command.description = command.description || 'No description';
        command.aliases = command.aliases || [];
        command.usage = command.usage || `.${command.command}`;
        command.owner = command.owner || false;
        command.group = command.group || false;
        command.admin = command.admin || false;
        command.premium = command.premium || false;
        command.elite = command.elite || false;
        command.cooldown = command.cooldown || 0;

        return true;
    }

    /**
     * إعادة تحميل ملف
     */
    async reloadFile(file) {
        this.bucy.logger?.info(`🔄 BucyLoader: Reloading ${file}...`);
        await this.loadFile(file);
    }

    /**
     * بدء المراقبة للتغييرات (مع منع Event Listener Leaks)
     */
    startWatching() {
        if (this.isWatching) {
            this.bucy.logger?.warn('⚠️ BucyLoader: Already watching');
            return;
        }

        // ✅ إزالة الـ Watcher القديم لمنع الـ Leaks
        if (this.watcher) {
            this.watcher.close();
            this.watcher = null;
        }

        this.bucy.logger?.info('👁️ BucyLoader: Starting file watcher...');

        this.watcher = chokidar.watch(this.commandsPath, {
            ignored: /(^|[\/\\])\../,
            persistent: true,
            ignoreInitial: true,
            awaitWriteFinish: {
                stabilityThreshold: 2000,
                pollInterval: 100
            }
        });

        // ✅ استخدام event listeners محدودة لمنع الـ Leaks
        this.watcher
            .once('ready', () => {
                this.bucy.logger?.info('👁️ BucyLoader: File watcher ready');
            })
            .on('add', async (filePath) => {
                const file = path.basename(filePath);
                if (file.endsWith('.js') && !this.loadingLock) {
                    this.bucy.logger?.info(`📄 BucyLoader: New file detected: ${file}`);
                    await this.loadFile(file);
                }
            })
            .on('change', async (filePath) => {
                const file = path.basename(filePath);
                if (file.endsWith('.js') && !this.loadingLock) {
                    this.bucy.logger?.info(`🔄 BucyLoader: File changed: ${file}`);
                    await this.reloadFile(file);
                }
            })
            .on('unlink', async (filePath) => {
                const file = path.basename(filePath);
                if (file.endsWith('.js')) {
                    this.bucy.logger?.info(`🗑️ BucyLoader: File removed: ${file}`);
                    this.loadedFiles.delete(file);
                    this.fileTimestamps.delete(file);
                }
            });

        this.isWatching = true;
        this.bucy.logger?.success('✅ BucyLoader: File watcher started');
    }

    /**
     * إيقاف المراقبة (مع تنظيف الـ Listeners)
     */
    stopWatching() {
        if (this.watcher) {
            // ✅ إزالة جميع الـ Listeners
            this.watcher.removeAllListeners();
            this.watcher.close();
            this.watcher = null;
            this.isWatching = false;
            this.bucy.logger?.info('👁️ BucyLoader: File watcher stopped');
        }
    }

    /**
     * الحصول على إحصائيات
     */
    getStats() {
        return {
            loadedFiles: this.loadedFiles.size,
            loadedCommands: this.loadedCommands.size,
            isWatching: this.isWatching,
            isLocked: this.loadingLock,
            commandsPath: this.commandsPath
        };
    }
}

export default BucyLoader;