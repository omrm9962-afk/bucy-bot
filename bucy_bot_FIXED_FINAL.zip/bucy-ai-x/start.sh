#!/bin/bash
# ================================================================
# BUCY AI X - Start Script (FIXED)
# ================================================================

echo "🚀 Starting BUCY AI X..."

# Check Node.js version
NODE_VER=$(node --version 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1)
if [ -z "$NODE_VER" ] || [ "$NODE_VER" -lt 18 ]; then
    echo "❌ Node.js 18+ required! Current: $(node --version 2>/dev/null || 'not installed')"
    exit 1
fi

echo "✅ Node.js $(node --version) detected"

# Install dependencies if not present
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ npm install failed!"
        exit 1
    fi
fi

# Load .env
if [ -f ".env" ]; then
    set -a
    source .env
    set +a
    echo "✅ .env loaded"
    echo "📌 Dashboard Port: ${DASHBOARD_PORT:-26450}"
fi

# Create required directories
mkdir -p Sessions Database Logs Backups Data Temp plugins

echo "✅ All directories created"
echo "✅ All checks passed, starting bot..."
echo ""
echo "╔══════════════════════════════════════╗"
echo "║  🤖 BUCY AI X v2.0.0 - By MARO      ║"  
echo "║  🌐 Dashboard: http://0.0.0.0:${DASHBOARD_PORT:-26450}  ║"
echo "║  👤 User: admin  |  🔑 Pass: admin123  ║"
echo "╚══════════════════════════════════════╝"
echo ""

node index.js
