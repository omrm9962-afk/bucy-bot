// ================================================================
// FILE: Services/MessageService.js
// ================================================================
// BUCY AI X - MESSAGE SERVICE
// ================================================================

import messages from '../Config/Messages.js';

class MessageService {
    constructor(bucy) {
        this.bucy = bucy;
        this.messages = messages;
    }

    get(path, variables = {}) {
        const keys = path.split('.');
        let message = this.messages;
        for (const key of keys) {
            if (message && typeof message === 'object' && key in message) {
                message = message[key];
            } else {
                return `❌ Message not found: ${path}`;
            }
        }

        if (typeof message !== 'string') {
            return `❌ Invalid message: ${path}`;
        }

        for (const [key, value] of Object.entries(variables)) {
            message = message.replace(`{${key}}`, value);
        }

        return message;
    }

    async sendSystem(jid, path, variables = {}, options = {}) {
        const text = this.get(path, variables);
        if (!text) return;
        return await this.bucy.sendMessage(jid, { text, ...options });
    }

    async sendError(jid, error, options = {}) {
        const text = this.get('system.error');
        this.bucy.logger?.error('Error:', error);
        return await this.bucy.sendMessage(jid, { text, ...options });
    }

    formatMenu(commands, categories) {
        let text = this.get('menu.title') + '\n\n';
        
        for (const category of categories) {
            const cmds = commands.filter(c => c.category === category);
            if (cmds.length === 0) continue;

            const emoji = {
                'system': '⚙️',
                'ai': '🤖',
                'media': '📥',
                'group': '👥',
                'owner': '👑',
                'general': '📌'
            }[category] || '📌';

            text += `${emoji} *${category.toUpperCase()}*\n`;
            text += '────────────────────\n';

            for (const cmd of cmds) {
                let aliases = '';
                if (cmd.aliases && cmd.aliases.length > 0) {
                    aliases = ` (${cmd.aliases.join(', ')})`;
                }
                let badges = '';
                if (cmd.owner) badges += ' 👑';
                if (cmd.premium) badges += ' ⭐';
                text += `▸ .${cmd.command}${aliases}${badges}\n`;
            }
            text += '\n';
        }

        text += '════════════════════════════════════\n';
        text += this.get('menu.total', { count: commands.length });
        text += '\n';
        text += this.get('menu.footer', { 
            botName: this.bucy.botName || 'BUCY AI X',
            version: this.bucy.botVersion || '2.0.0'
        });

        return text;
    }
}

export default MessageService;