// ================================================================
// FILE: Services/HealthMonitor.js
// ================================================================
// BUCY AI X - HEALTH MONITOR
// ================================================================

import os from 'os';
import process from 'process';

class HealthMonitor {
    constructor(bucy) {
        this.bucy = bucy;
        this.healthInterval = null;
        this.isRunning = false;
        this.healthData = {};
        this.healthCheckCount = 0;
    }

    start() {
        if (this.isRunning) {
            this.bucy.logger?.warn('⚠️ Health monitor already running');
            return;
        }

        this.isRunning = true;
        this.bucy.logger?.info('📊 Health monitor started');

        this.updateHealth();
        this.healthInterval = setInterval(() => {
            this.updateHealth();
        }, 30000);
    }

    stop() {
        if (this.healthInterval) {
            clearInterval(this.healthInterval);
            this.healthInterval = null;
        }
        this.isRunning = false;
        this.bucy.logger?.info('📊 Health monitor stopped');
    }

    updateHealth() {
        this.healthCheckCount++;

        const mem = process.memoryUsage();
        const loadavg = os.loadavg();
        const uptime = process.uptime();
        const totalMem = os.totalmem();
        const freeMem = os.freemem();

        // ✅ RAM Usage
        const memoryInfo = {
            heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
            heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
            rss: Math.round(mem.rss / 1024 / 1024),
            total: Math.round(totalMem / 1024 / 1024 / 1024),
            free: Math.round(freeMem / 1024 / 1024 / 1024),
            usagePercent: Math.round(((totalMem - freeMem) / totalMem) * 100)
        };

        // ✅ CPU Usage
        const cpuInfo = {
            loadavg: loadavg.map(v => Math.round(v * 100) / 100),
            cores: os.cpus().length,
            model: os.cpus()[0]?.model || 'Unknown',
            speed: os.cpus()[0]?.speed || 0
        };

        // ✅ Bot Stats
        const botInfo = {
            isRunning: this.bucy.isRunning || false,
            isConnected: !!this.bucy.sock,
            botName: this.bucy.botName || 'BUCY AI X',
            botVersion: this.bucy.botVersion || '2.0.0',
            uptime: Math.floor(uptime),
            uptimeFormatted: this.formatUptime(uptime),
            messageCount: this.bucy.messageCount || 0,
            commandCount: this.bucy.commandCount || 0,
            errorCount: this.bucy.errorCount || 0
        };

        // ✅ Database Stats
        const dbInfo = {
            users: this.bucy.database?.count('users') || 0,
            groups: this.bucy.database?.count('groups') || 0,
            premium: this.bucy.database?.count('premium') || 0
        };

        // ✅ Services & Plugins
        const servicesInfo = {
            loaded: this.getLoadedServices(),
            plugins: this.bucy.pluginManager?.plugins?.size || 0,
            commands: this.bucy.commandHandler?.commands?.size || 0,
            activeSessions: this.bucy.sessionManager?.activeSessions?.size || 0
        };

        // ✅ Process
        const processInfo = {
            pid: process.pid,
            title: process.title,
            version: process.version,
            platform: os.platform(),
            arch: os.arch(),
            nodeEnv: process.env.NODE_ENV || 'development'
        };

        this.healthData = {
            timestamp: Date.now(),
            timestampISO: new Date().toISOString(),
            healthChecks: this.healthCheckCount,
            memory: memoryInfo,
            cpu: cpuInfo,
            bot: botInfo,
            database: dbInfo,
            services: servicesInfo,
            process: processInfo
        };

        globalThis.BucyHealth = this.healthData;

        // عرض إحصائيات دورية
        if (this.healthCheckCount % 10 === 0) {
            this.bucy.logger?.info(`📊 Health: ${botInfo.messageCount} msgs, ${botInfo.commandCount} cmds, ${servicesInfo.activeSessions} sessions`);
        }

        return this.healthData;
    }

    getLoadedServices() {
        const services = [];
        if (this.bucy.database) services.push('Database');
        if (this.bucy.commandHandler) services.push('CommandHandler');
        if (this.bucy.messageHandler) services.push('MessageHandler');
        if (this.bucy.eventHandler) services.push('EventHandler');
        if (this.bucy.pluginManager) services.push('PluginManager');
        if (this.bucy.statistics) services.push('Statistics');
        if (this.bucy.cacheManager) services.push('CacheManager');
        if (this.bucy.securityManager) services.push('SecurityManager');
        if (this.bucy.sessionManager) services.push('SessionManager');
        if (this.bucy.pairingManager) services.push('PairingManager');
        return services;
    }

    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);

        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        parts.push(`${secs}s`);

        return parts.join(' ');
    }

    getHealth() {
        return this.healthData;
    }

    getQuickStats() {
        const health = this.healthData;
        return {
            uptime: health.bot?.uptimeFormatted || '0s',
            users: health.database?.users || 0,
            groups: health.database?.groups || 0,
            commands: health.bot?.commandCount || 0,
            messages: health.bot?.messageCount || 0,
            memory: health.memory?.heapUsed || 0,
            cpu: health.cpu?.loadavg?.[0] || 0,
            sessions: health.services?.activeSessions || 0,
            status: health.bot?.isRunning ? '🟢 Online' : '🔴 Offline'
        };
    }
}

export default HealthMonitor;