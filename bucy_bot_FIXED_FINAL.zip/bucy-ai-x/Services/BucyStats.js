// ================================================================
// FILE: Services/BucyStats.js
// ================================================================
// BUCY AI X - PLUGIN STATISTICS
// ================================================================

class BucyStats {
    constructor(bucy) {
        this.bucy = bucy;
        this.stats = {
            commands: 0,
            categories: {},
            aliases: 0,
            disabled: 0,
            services: 0,
            owners: 0,
            premium: 0,
            groups: 0,
            users: 0,
            messages: 0,
            errors: 0,
            uptime: 0
        };
    }

    /**
     * تحديث الإحصائيات
     */
    update() {
        const commands = this.bucy.commandHandler?.getCommands() || [];
        
        this.stats.commands = commands.length;
        this.stats.aliases = commands.reduce((acc, cmd) => acc + (cmd.aliases?.length || 0), 0);
        this.stats.categories = this.getCategoryStats(commands);
        this.stats.services = this.getServiceStats();
        this.stats.owners = this.bucy.config?.owners?.length || 0;
        this.stats.premium = this.bucy.database?.count('premium') || 0;
        this.stats.groups = this.bucy.database?.count('groups') || 0;
        this.stats.users = this.bucy.database?.count('users') || 0;
        this.stats.messages = this.bucy.messageCount || 0;
        this.stats.errors = this.bucy.errorCount || 0;
        this.stats.uptime = Math.floor((Date.now() - (this.bucy.startTime || Date.now())) / 1000);

        return this.stats;
    }

    /**
     * إحصائيات الفئات
     */
    getCategoryStats(commands) {
        const categories = {};
        for (const cmd of commands) {
            const category = cmd.category || 'General';
            if (!categories[category]) {
                categories[category] = 0;
            }
            categories[category]++;
        }
        return categories;
    }

    /**
     * إحصائيات الخدمات
     */
    getServiceStats() {
        let count = 0;
        if (this.bucy.database) count++;
        if (this.bucy.commandHandler) count++;
        if (this.bucy.messageHandler) count++;
        if (this.bucy.eventHandler) count++;
        if (this.bucy.pluginManager) count++;
        if (this.bucy.statistics) count++;
        if (this.bucy.cacheManager) count++;
        if (this.bucy.securityManager) count++;
        if (this.bucy.sessionManager) count++;
        if (this.bucy.pairingManager) count++;
        if (this.bucy.healthMonitor) count++;
        if (this.bucy.recovery) count++;
        return count;
    }

    /**
     * الحصول على إحصائيات سريعة
     */
    getQuickStats() {
        return {
            commands: this.stats.commands,
            categories: Object.keys(this.stats.categories).length,
            services: this.stats.services,
            users: this.stats.users,
            groups: this.stats.groups,
            premium: this.stats.premium,
            messages: this.stats.messages,
            errors: this.stats.errors,
            uptime: this.formatUptime(this.stats.uptime)
        };
    }

    /**
     * تنسيق وقت التشغيل
     */
    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);

        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        parts.push(`${secs}s`);

        return parts.join(' ');
    }

    /**
     * الحصول على تقرير كامل
     */
    getReport() {
        this.update();
        return {
            ...this.stats,
            categories: this.stats.categories,
            quickStats: this.getQuickStats(),
            timestamp: Date.now(),
            timestampISO: new Date().toISOString()
        };
    }
}

export default BucyStats;