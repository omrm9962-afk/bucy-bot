// ================================================================
// FILE: Services/Logger.js
// ================================================================
// BUCY AI X - UNIFIED LOGGER
// ================================================================

import chalk from 'chalk';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Logger {
    constructor() {
        this.logLevel = 'info';
        this.logFile = path.join(__dirname, '../Logs/activity.log');
        this.errorFile = path.join(__dirname, '../Logs/errors.log');
        this.enableFileLogging = true;
        this.enableConsoleLogging = true;
        this.ensureLogDirectory();
    }

    async ensureLogDirectory() {
        try {
            const logDir = path.join(__dirname, '../Logs');
            if (!fs.existsSync(logDir)) {
                await fs.mkdir(logDir, { recursive: true });
            }
        } catch (error) {
            console.error('Failed to create logs directory:', error);
        }
    }

    formatMessage(type, message, color) {
        const timestamp = new Date().toISOString();
        return color(`[${timestamp}] ${type}: ${message}`);
    }

    // ================================================================
    // 📌 LOG LEVELS
    // ================================================================

    info(message) {
        const formatted = this.formatMessage('INFO', message, chalk.blue);
        if (this.enableConsoleLogging) console.log(formatted);
        if (this.enableFileLogging) this.logToFile('INFO', message);
    }

    success(message) {
        const formatted = this.formatMessage('SUCCESS', message, chalk.green);
        if (this.enableConsoleLogging) console.log(formatted);
        if (this.enableFileLogging) this.logToFile('SUCCESS', message);
    }

    warn(message) {
        const formatted = this.formatMessage('WARN', message, chalk.yellow);
        if (this.enableConsoleLogging) console.log(formatted);
        if (this.enableFileLogging) this.logToFile('WARN', message);
    }

    error(message, error = null) {
        const formatted = this.formatMessage('ERROR', message, chalk.red);
        if (this.enableConsoleLogging) console.log(formatted);
        if (this.enableFileLogging) this.logToFile('ERROR', message);
        
        if (error) {
            const errorFormatted = this.formatMessage('ERROR', error.stack || error.message, chalk.red);
            if (this.enableConsoleLogging) console.log(errorFormatted);
            if (this.enableFileLogging) this.logToFile('ERROR', error.stack || error.message);
        }
    }

    debug(message) {
        if (this.logLevel === 'debug') {
            const formatted = this.formatMessage('DEBUG', message, chalk.gray);
            if (this.enableConsoleLogging) console.log(formatted);
            if (this.enableFileLogging) this.logToFile('DEBUG', message);
        }
    }

    // ================================================================
    // 📁 FILE LOGGING
    // ================================================================

    logToFile(level, message) {
        try {
            const timestamp = new Date().toISOString();
            const logLine = `[${timestamp}] ${level}: ${message}\n`;
            fs.appendFileSync(this.logFile, logLine);
            if (level === 'ERROR') {
                fs.appendFileSync(this.errorFile, logLine);
            }
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }

    // ================================================================
    // 🎨 HEADER
    // ================================================================

    header(text) {
        if (this.enableConsoleLogging) {
            console.log(chalk.cyan('═══════════════════════════════════════════════════════════════'));
            console.log(chalk.cyan(`║                    ${text}                    ║`));
            console.log(chalk.cyan('═══════════════════════════════════════════════════════════════'));
        }
    }

    // ================================================================
    // ⚙️ CONFIG
    // ================================================================

    setLevel(level) {
        const validLevels = ['debug', 'info', 'warn', 'error'];
        if (validLevels.includes(level)) {
            this.logLevel = level;
        }
    }

    // ================================================================
    // 📖 READ LOGS
    // ================================================================

    getLogs(limit = 100) {
        try {
            if (!fs.existsSync(this.logFile)) return [];
            const content = fs.readFileSync(this.logFile, 'utf8');
            const lines = content.split('\n').filter(line => line.trim());
            return lines.slice(-limit);
        } catch (error) {
            return [];
        }
    }

    getErrors(limit = 50) {
        try {
            if (!fs.existsSync(this.errorFile)) return [];
            const content = fs.readFileSync(this.errorFile, 'utf8');
            const lines = content.split('\n').filter(line => line.trim());
            return lines.slice(-limit);
        } catch (error) {
            return [];
        }
    }
}

export default Logger;