// ================================================================
// FILE: Services/BucyRecovery.js
// ================================================================
// BUCY AI X - ERROR RECOVERY
// ================================================================

import process from 'process';

class BucyRecovery {
    constructor(bucy) {
        this.bucy = bucy;
        this.isRecovering = false;
        this.recoveryAttempts = 0;
        this.maxRecoveryAttempts = 5;
        this.errors = [];
        this.fatalErrors = [
            'AUTH_FATAL',
            'SESSION_FATAL',
            'DB_FATAL',
            'SOCKET_FATAL',
            'CONFIG_FATAL',
            'MEMORY_FATAL'
        ];
    }

    /**
     * بدء نظام الاسترداد
     */
    start() {
        this.bucy.logger?.info('🔄 Recovery system started');
        this.setupUncaughtException();
        this.setupUnhandledRejection();
        this.setupProcessExit();
    }

    /**
     * التعامل مع UncaughtException
     */
    setupUncaughtException() {
        process.on('uncaughtException', async (error) => {
            this.bucy.logger?.error('💥 Uncaught Exception:', error);
            await this.handleError(error, 'uncaughtException');
        });
    }

    /**
     * التعامل مع UnhandledRejection
     */
    setupUnhandledRejection() {
        process.on('unhandledRejection', async (reason) => {
            this.bucy.logger?.error('💥 Unhandled Rejection:', reason);
            await this.handleError(reason, 'unhandledRejection');
        });
    }

    /**
     * التعامل مع Process Exit
     */
    setupProcessExit() {
        process.on('exit', (code) => {
            if (code !== 0) {
                this.bucy.logger?.warn(`⚠️ Process exited with code: ${code}`);
                this.errors.push({
                    type: 'exit',
                    code: code,
                    timestamp: Date.now()
                });
            }
        });
    }

    /**
     * معالجة الخطأ
     */
    async handleError(error, type) {
        const errorInfo = {
            type: type,
            message: error?.message || String(error),
            stack: error?.stack,
            code: error?.code || 'UNKNOWN',
            timestamp: Date.now(),
            recovered: false
        };

        this.errors.push(errorInfo);

        // التحقق من الخطأ القاتل
        if (this.isFatalError(error)) {
            this.bucy.logger?.error(`💀 Fatal error detected: ${errorInfo.message}`);
            await this.handleFatalError(errorInfo);
            return;
        }

        // محاولة الاسترداد
        if (this.canRecover()) {
            await this.attemptRecovery(errorInfo);
        } else {
            this.bucy.logger?.error(`❌ Max recovery attempts reached, shutting down`);
            await this.shutdown();
        }
    }

    /**
     * التحقق من الخطأ القاتل
     */
    isFatalError(error) {
        const message = error?.message || String(error);
        const code = error?.code || '';

        // التحقق من الكود
        if (this.fatalErrors.includes(code)) {
            return true;
        }

        // التحقق من النص
        const fatalPatterns = [
            'logged out',
            'invalid session',
            'authentication failed',
            'database corrupted',
            'out of memory',
            'cannot read properties of null'
        ];

        return fatalPatterns.some(pattern => message.includes(pattern));
    }

    /**
     * التحقق من إمكانية الاسترداد
     */
    canRecover() {
        return this.recoveryAttempts < this.maxRecoveryAttempts;
    }

    /**
     * محاولة الاسترداد
     */
    async attemptRecovery(errorInfo) {
        if (this.isRecovering) {
            this.bucy.logger?.warn('⚠️ Recovery already in progress');
            return;
        }

        this.isRecovering = true;
        this.recoveryAttempts++;

        this.bucy.logger?.info(`🔄 Recovery attempt ${this.recoveryAttempts}/${this.maxRecoveryAttempts}`);

        try {
            // إعادة تهيئة البوت
            if (this.bucy.sock) {
                this.bucy.logger?.info('🔌 Closing old socket...');
                await this.bucy.whatsAppService?.closeSocket();
            }

            // إعادة الاتصال
            this.bucy.logger?.info('🔄 Reconnecting...');
            await this.bucy.connect();

            errorInfo.recovered = true;
            this.isRecovering = false;
            this.recoveryAttempts = 0;

            this.bucy.logger?.success('✅ Recovery successful!');

        } catch (error) {
            this.bucy.logger?.error('❌ Recovery failed:', error);
            this.isRecovering = false;

            if (this.canRecover()) {
                this.bucy.logger?.info(`⏳ Retrying recovery in ${this.recoveryAttempts * 2}s...`);
                setTimeout(() => this.attemptRecovery(errorInfo), this.recoveryAttempts * 2000);
            } else {
                await this.shutdown();
            }
        }
    }

    /**
     * معالجة الخطأ القاتل
     */
    async handleFatalError(errorInfo) {
        this.bucy.logger?.error(`💀 Fatal error: ${errorInfo.message}`);
        
        // محاولة حفظ البيانات
        try {
            await this.bucy.database?.saveAll();
            await this.bucy.statistics?.saveStats();
        } catch (e) {
            this.bucy.logger?.error('Failed to save data:', e);
        }

        // إغلاق البوت
        await this.shutdown(`Fatal error: ${errorInfo.message}`);
    }

    /**
     * إغلاق البوت
     */
    async shutdown(reason = 'Shutdown requested') {
        this.bucy.logger?.warn(`🔴 Shutting down: ${reason}`);
        
        if (this.bucy.shutdown) {
            await this.bucy.shutdown(reason);
        } else {
            process.exit(1);
        }
    }

    /**
     * الحصول على إحصائيات الأخطاء
     */
    getStats() {
        return {
            totalErrors: this.errors.length,
            recoveryAttempts: this.recoveryAttempts,
            maxRecoveryAttempts: this.maxRecoveryAttempts,
            isRecovering: this.isRecovering,
            recentErrors: this.errors.slice(-5),
            fatalErrors: this.errors.filter(e => e.recovered === false).length
        };
    }
}

export default BucyRecovery;