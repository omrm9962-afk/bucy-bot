// ================================================================
// FILE: Services/PairingManager.js
// ================================================================
// BUCY AI X - PAIRING MANAGEMENT (FIXED)
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class PairingManager {
    constructor(bucy) {
        this.bucy = bucy;
        this.pairingCodes = new Map();
        this.activePairings = new Map();
        this.pairingPath = path.join(__dirname, '../Data/pairing.json');
        this.pairingTimeout = 300000; // 5 minutes
        this.cleanupInterval = null;
        this.isCleaning = false;
    }

    /**
     * بدء التنظيف التلقائي
     */
    startCleanupScheduler() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }

        this.cleanupInterval = setInterval(() => {
            this.cleanExpired();
        }, 60000); // كل دقيقة

        this.bucy.logger?.info('🧹 Pairing cleanup scheduler started');
    }

    /**
     * إيقاف التنظيف
     */
    stopCleanupScheduler() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
            this.bucy.logger?.info('🧹 Pairing cleanup scheduler stopped');
        }
    }

    /**
     * إنشاء كود Pairing حقيقي (مع منع Race Conditions)
     */
    async requestPairing(phoneNumber, sock) {
        try {
            const cleaned = phoneNumber.replace(/\D/g, '');
            
            // ✅ منع إنشاء أكثر من pairing لنفس الرقم
            if (this.activePairings.has(cleaned)) {
                const existing = this.activePairings.get(cleaned);
                if (Date.now() < existing.expiresAt) {
                    return {
                        success: false,
                        error: 'PAIRING_ACTIVE',
                        message: 'Pairing already active for this number',
                        code: existing.code,
                        expiresIn: Math.floor((existing.expiresAt - Date.now()) / 1000)
                    };
                }
                this.activePairings.delete(cleaned);
            }

            // ✅ استخدام Lock لمنع Race Conditions
            if (this.isPairingInProgress) {
                return {
                    success: false,
                    error: 'PAIRING_IN_PROGRESS',
                    message: 'Another pairing is in progress'
                };
            }

            this.isPairingInProgress = true;

            try {
                // ✅ طلب كود من Baileys
                const code = await sock.requestPairingCode(cleaned);

                // ✅ حفظ الكود
                const pairingData = {
                    phone: cleaned,
                    code: code,
                    createdAt: Date.now(),
                    expiresAt: Date.now() + this.pairingTimeout,
                    status: 'pending',
                    attempts: 0,
                    lastAttempt: null
                };

                this.activePairings.set(cleaned, pairingData);
                await this.savePairingInfo(cleaned, pairingData);

                this.bucy.logger?.success(`✅ Pairing code generated: ${code}`);

                return {
                    success: true,
                    code: code,
                    phoneNumber: cleaned,
                    expiresIn: Math.floor(this.pairingTimeout / 1000),
                    status: 'pending'
                };

            } finally {
                this.isPairingInProgress = false;
            }

        } catch (error) {
            this.bucy.logger?.error('❌ Pairing request failed:', error);
            this.isPairingInProgress = false;
            return {
                success: false,
                error: error.message || 'PAIRING_FAILED',
                message: 'Failed to generate pairing code'
            };
        }
    }

    /**
     * تنظيف الأكواد المنتهية (مع منع التكرار)
     */
    cleanExpired() {
        if (this.isCleaning) return;
        this.isCleaning = true;

        const now = Date.now();
        let cleaned = 0;

        try {
            for (const [phone, data] of this.activePairings) {
                if (now > data.expiresAt) {
                    this.activePairings.delete(phone);
                    cleaned++;
                }
            }

            // ✅ حفظ التغييرات
            if (cleaned > 0) {
                this.savePairingsToFile();
                this.bucy.logger?.info(`🧹 Cleaned ${cleaned} expired pairings`);
            }
        } catch (error) {
            this.bucy.logger?.error('Error cleaning pairings:', error);
        } finally {
            this.isCleaning = false;
        }

        return cleaned;
    }

    /**
     * حفظ جميع الـ Pairings في الملف
     */
    async savePairingsToFile() {
        try {
            const data = {};
            for (const [phone, info] of this.activePairings) {
                data[phone] = info;
            }
            await fs.writeJson(this.pairingPath, data, { spaces: 2 });
        } catch (error) {
            this.bucy.logger?.error('Failed to save pairings:', error);
        }
    }

    /**
     * حفظ Pairing واحد
     */
    async savePairingInfo(phoneNumber, data) {
        try {
            const allData = await fs.readJson(this.pairingPath).catch(() => ({}));
            allData[phoneNumber] = {
                ...data,
                savedAt: Date.now()
            };
            await fs.writeJson(this.pairingPath, allData, { spaces: 2 });
        } catch (error) {
            this.bucy.logger?.error('Failed to save pairing info:', error);
        }
    }

    /**
     * تحميل Pairing من الملف (مع تنظيف المنتهي)
     */
    async loadPairingInfo() {
        try {
            if (await fs.pathExists(this.pairingPath)) {
                const data = await fs.readJson(this.pairingPath);
                const now = Date.now();
                let loaded = 0;

                for (const [phone, info] of Object.entries(data)) {
                    if (info.expiresAt > now && info.status === 'pending') {
                        this.activePairings.set(phone, info);
                        loaded++;
                    }
                }

                this.bucy.logger?.info(`📋 Loaded ${loaded} active pairings`);
            }
        } catch (error) {
            this.bucy.logger?.error('Failed to load pairing info:', error);
        }
    }

    /**
     * التحقق من صحة Pairing
     */
    isValidPairing(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        const data = this.activePairings.get(cleaned);
        
        if (!data) return false;
        if (Date.now() > data.expiresAt) {
            this.activePairings.delete(cleaned);
            return false;
        }
        return true;
    }

    /**
     * الحصول على إحصائيات
     */
    getStats() {
        const now = Date.now();
        let active = 0;
        let expired = 0;

        for (const [, data] of this.activePairings) {
            if (now > data.expiresAt) {
                expired++;
            } else {
                active++;
            }
        }

        return {
            active: active,
            expired: expired,
            total: this.activePairings.size,
            cleanupInterval: this.cleanupInterval ? 'active' : 'stopped'
        };
    }
}

export default PairingManager;