// ================================================================
// FILE: Services/Statistics.js
// ================================================================
// BUCY AI X - STATISTICS SYSTEM
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Statistics {
    constructor(bucy) {
        this.bucy = bucy;
        this.stats = {
            users: 0,
            groups: 0,
            commands: 0,
            messages: 0,
            errors: 0,
            uptime: 0,
            startTime: Date.now(),
            dailyStats: {},
            monthlyStats: {}
        };
        this.statsPath = path.join(__dirname, '../Data/stats.json');
    }

    async loadStats() {
        try {
            if (await fs.pathExists(this.statsPath)) {
                const data = await fs.readJson(this.statsPath);
                this.stats = { ...this.stats, ...data };
                this.bucy.logger?.info('Statistics loaded from disk');
            }
        } catch (error) {
            this.bucy.logger?.error('Failed to load stats:', error);
        }
    }

    async saveStats() {
        try {
            this.stats.uptime = Math.floor((Date.now() - this.stats.startTime) / 1000);
            await fs.writeJson(this.statsPath, this.stats, { spaces: 2 });
            return true;
        } catch (error) {
            this.bucy.logger?.error('Failed to save stats:', error);
            return false;
        }
    }

    async updateStats(type, data = {}) {
        try {
            switch (type) {
                case 'user':
                    this.stats.users = data.count || this.stats.users + 1;
                    this.stats.dailyStats.users = (this.stats.dailyStats.users || 0) + 1;
                    break;
                case 'group':
                    this.stats.groups = data.count || this.stats.groups + 1;
                    break;
                case 'command':
                    this.stats.commands++;
                    this.stats.dailyStats.commands = (this.stats.dailyStats.commands || 0) + 1;
                    break;
                case 'message':
                    this.stats.messages++;
                    this.stats.dailyStats.messages = (this.stats.dailyStats.messages || 0) + 1;
                    break;
                case 'error':
                    this.stats.errors++;
                    break;
                default:
                    this.stats = { ...this.stats, ...data };
            }
            await this.saveStats();
        } catch (error) {
            this.bucy.logger?.error('Failed to update stats:', error);
        }
    }

    getStats() {
        return {
            ...this.stats,
            uptime: this.getUptime(),
            formattedUptime: this.getFormattedUptime(),
            dailyStats: this.stats.dailyStats,
            monthlyStats: this.stats.monthlyStats
        };
    }

    getUptime() {
        return Math.floor((Date.now() - this.stats.startTime) / 1000);
    }

    getFormattedUptime() {
        const uptime = this.getUptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = uptime % 60;
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        parts.push(`${seconds}s`);
        return parts.join(' ');
    }
}

export default Statistics;