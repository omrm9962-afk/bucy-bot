// ================================================================
// FILE: Services/Database.js (FIXED - added elite collection)
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Database {
    constructor(bucy) {
        this.bucy = bucy;
        this.dbPath = path.join(__dirname, '../Database');
        this.collections = {};
        this.cache = {};
        this.isInitialized = false;
    }

    async initialize() {
        try {
            await fs.ensureDir(this.dbPath);
            // ✅ FIX: Added 'elite' collection
            const collections = ['users', 'groups', 'settings', 'premium', 'elite', 'ban', 'warns', 'stats', 'logs'];
            for (const name of collections) {
                const filePath = path.join(this.dbPath, `${name}.json`);
                if (!await fs.pathExists(filePath)) await fs.writeJson(filePath, {});
                this.collections[name] = filePath;
                this.cache[name] = {};
            }
            for (const name of collections) await this.loadCollection(name);
            this.isInitialized = true;
            this.bucy?.logger?.info(`Database initialized with ${collections.length} collections`);
        } catch (error) {
            this.bucy?.logger?.error('Database initialization failed:', error);
            throw error;
        }
    }

    async loadCollection(name) {
        try {
            const filePath = this.collections[name];
            if (await fs.pathExists(filePath)) {
                this.cache[name] = await fs.readJson(filePath);
            } else {
                this.cache[name] = {};
                await fs.writeJson(filePath, {});
            }
        } catch (error) {
            this.bucy?.logger?.error(`Failed to load collection ${name}:`, error);
            throw error;
        }
    }

    async saveCollection(name) {
        try {
            const filePath = this.collections[name];
            await fs.writeJson(filePath, this.cache[name] || {}, { spaces: 2 });
            return true;
        } catch (error) {
            this.bucy?.logger?.error(`Failed to save ${name}:`, error);
            return false;
        }
    }

    get(collection, key) {
        return this.cache[collection]?.[key] || null;
    }

    async set(collection, key, value) {
        if (!this.cache[collection]) this.cache[collection] = {};
        this.cache[collection][key] = value;
        return await this.saveCollection(collection);
    }

    async delete(collection, key) {
        if (!this.cache[collection]) return false;
        delete this.cache[collection][key];
        return await this.saveCollection(collection);
    }

    find(collection, filter = {}) {
        if (!this.cache[collection]) return [];
        return Object.entries(this.cache[collection])
            .filter(([, item]) => Object.entries(filter).every(([k, v]) => item[k] === v))
            .map(([key, item]) => ({ key, ...item }));
    }

    findOne(collection, filter = {}) {
        return this.find(collection, filter)[0] || null;
    }

    getAll(collection) {
        if (!this.cache[collection]) return [];
        return Object.entries(this.cache[collection]).map(([key, val]) => ({ key, ...val }));
    }

    count(collection) {
        return Object.keys(this.cache[collection] || {}).length;
    }

    exists(collection, key) {
        return !!this.cache[collection]?.[key];
    }

    async saveAll() {
        for (const name of Object.keys(this.cache)) await this.saveCollection(name);
        this.bucy?.logger?.info('All collections saved');
    }

    async close() {
        await this.saveAll();
        this.bucy?.logger?.info('Database closed');
    }
}

export default Database;
