// ================================================================
// FILE: Services/PluginManager.js
// ================================================================
// BUCY AI X - PLUGIN MANAGEMENT
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class PluginManager {
    constructor(bucy) {
        this.bucy = bucy;
        this.plugins = new Map();
        this.pluginsPath = path.join(__dirname, '../plugins');
        this.disabledPlugins = new Set();
    }

    // ================================================================
    // ✅ SAFE LOGGER HELPER
    // ================================================================

    log(message, type = 'info') {
        if (this.bucy && this.bucy.logger) {
            if (type === 'info') this.bucy.logger.info(message);
            else if (type === 'success') this.bucy.logger.success(message);
            else if (type === 'warn') this.bucy.logger.warn(message);
            else if (type === 'error') this.bucy.logger.error(message);
            else if (type === 'debug') this.bucy.logger.debug(message);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
    }

    // ================================================================
    // 📂 LOAD ALL PLUGINS
    // ================================================================

    async loadAllPlugins() {
        try {
            this.log('Loading plugins...', 'info');
            await fs.ensureDir(this.pluginsPath);

            const files = await fs.readdir(this.pluginsPath);
            const pluginFiles = files.filter(file => file.endsWith('.js'));

            let loaded = 0;

            for (const file of pluginFiles) {
                try {
                    const filePath = path.join(this.pluginsPath, file);
                    const timestamp = Date.now();
                    const { default: plugin } = await import(`file://${filePath}?t=${timestamp}`);
                    
                    if (this.validatePlugin(plugin)) {
                        const pluginId = plugin.id || plugin.name.toLowerCase().replace(/\s+/g, '_');
                        this.plugins.set(pluginId, {
                            ...plugin,
                            file,
                            id: pluginId,
                            loadedAt: Date.now()
                        });
                        loaded++;
                        this.log(`Loaded plugin: ${plugin.name}`, 'success');
                    }
                } catch (error) {
                    this.log(`Failed to load plugin ${file}: ${error.message}`, 'error');
                    if (this.bucy && this.bucy.logger) {
                        this.bucy.logger.debug(error.stack);
                    }
                }
            }

            this.log(`Loaded ${loaded} plugins`, 'success');

        } catch (error) {
            this.log(`Failed to load plugins: ${error.message}`, 'error');
            if (this.bucy && this.bucy.logger) {
                this.bucy.logger.error('Failed to load plugins:', error);
            }
            throw error;
        }
    }

    // ================================================================
    // ✅ VALIDATE PLUGIN
    // ================================================================

    validatePlugin(plugin) {
        if (!plugin.name) {
            this.log('Plugin missing name', 'warn');
            return false;
        }

        if (typeof plugin.execute !== 'function') {
            this.log(`Plugin ${plugin.name} missing execute function`, 'warn');
            return false;
        }

        return true;
    }

    // ================================================================
    // 📌 GET PLUGIN INFO
    // ================================================================

    getPluginInfo(pluginId) {
        const plugin = this.plugins.get(pluginId);
        if (!plugin) return null;
        return {
            id: plugin.id,
            name: plugin.name,
            version: plugin.version || '1.0.0',
            author: plugin.author || 'Unknown',
            description: plugin.description || 'No description',
            enabled: !this.disabledPlugins.has(pluginId),
            loadedAt: new Date(plugin.loadedAt).toISOString()
        };
    }

    // ================================================================
    // 📋 GET ALL PLUGINS
    // ================================================================

    getAllPlugins() {
        const list = [];
        for (const [id] of this.plugins) {
            list.push(this.getPluginInfo(id));
        }
        return list;
    }

    // ================================================================
    // 📊 GET STATS
    // ================================================================

    getStats() {
        return {
            total: this.plugins.size,
            enabled: this.plugins.size - this.disabledPlugins.size,
            disabled: this.disabledPlugins.size
        };
    }
}

export default PluginManager;