// ================================================================
// FILE: Managers/CacheManager.js
// ================================================================
// BUCY AI X - CACHE MANAGEMENT
// ================================================================

class CacheManager {
    constructor(bucy) {
        this.bucy = bucy;
        this.cache = new Map();
        this.defaultTTL = 600000;
    }

    set(key, value, ttl = this.defaultTTL) {
        this.cache.set(key, {
            value: value,
            expires: Date.now() + ttl
        });
        return true;
    }

    get(key) {
        const entry = this.cache.get(key);
        if (!entry) return null;
        if (Date.now() > entry.expires) {
            this.cache.delete(key);
            return null;
        }
        return entry.value;
    }

    delete(key) {
        return this.cache.delete(key);
    }

    clear() {
        this.cache.clear();
        this.bucy.logger?.info('Cache cleared');
    }

    clearExpired() {
        const now = Date.now();
        let cleared = 0;
        for (const [key, entry] of this.cache) {
            if (now > entry.expires) {
                this.cache.delete(key);
                cleared++;
            }
        }
        if (cleared > 0) {
            this.bucy.logger?.info(`Cleared ${cleared} expired cache items`);
        }
        return cleared;
    }

    getSize() {
        return this.cache.size;
    }
}

export default CacheManager;