// ================================================================
// FILE: Managers/SessionManager.js
// ================================================================
// BUCY AI X - SESSION MANAGEMENT (FIXED)
// ================================================================

import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class SessionManager {
    constructor(bucy) {
        this.bucy = bucy;
        this.sessionPath = path.join(__dirname, '../Sessions');
        this.activeSessions = new Map();
        this.lockedSessions = new Set();
        this.sessionCache = new Map();
        this.sessionTimeout = 3600000; // 1 hour
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.recoveryInterval = null;
    }

    /**
     * بدء مراقبة الجلسات
     */
    startRecoveryScheduler() {
        if (this.recoveryInterval) {
            clearInterval(this.recoveryInterval);
        }

        this.recoveryInterval = setInterval(async () => {
            await this.performRecovery();
        }, 60000); // كل دقيقة

        this.bucy.logger?.info('🔄 Session recovery scheduler started');
    }

    /**
     * إيقاف مراقبة الجلسات
     */
    stopRecoveryScheduler() {
        if (this.recoveryInterval) {
            clearInterval(this.recoveryInterval);
            this.recoveryInterval = null;
            this.bucy.logger?.info('🔄 Session recovery scheduler stopped');
        }
    }

    /**
     * التحقق من سلامة الجلسات وإصلاحها
     */
    async performRecovery() {
        try {
            for (const [phone, data] of this.activeSessions) {
                // ✅ التحقق من صلاحية الجلسة
                if (!await this.checkSessionIntegrity(phone)) {
                    this.bucy.logger?.warn(`⚠️ Session ${phone} corrupted, attempting repair...`);
                    await this.repairSession(phone);
                }

                // ✅ التحقق من انتهاء الجلسة
                if (Date.now() - data.lastActivity > this.sessionTimeout) {
                    this.bucy.logger?.warn(`⚠️ Session ${phone} expired`);
                    await this.removeActiveSession(phone);
                }
            }

            // ✅ تنظيف الجلسات التالفة
            await this.cleanCorruptedSessions();

        } catch (error) {
            this.bucy.logger?.error('Recovery error:', error);
        }
    }

    /**
     * التحقق من سلامة الجلسة
     */
    async checkSessionIntegrity(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        const session = this.activeSessions.get(cleaned);
        
        if (!session) return false;

        // ✅ التحقق من وجود ملفات الجلسة
        const sessionDir = this.getSessionPath(cleaned);
        const credsPath = path.join(sessionDir, 'creds.json');

        if (!await fs.pathExists(credsPath)) {
            return false;
        }

        // ✅ التحقق من صحة ملفات الجلسة
        try {
            const creds = await fs.readJson(credsPath);
            const required = ['noiseKey', 'signedIdentityKey', 'signedPreKey'];
            for (const key of required) {
                if (!creds[key]) {
                    return false;
                }
            }
            return true;
        } catch {
            return false;
        }
    }

    /**
     * إصلاح الجلسة التالفة
     */
    async repairSession(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        
        try {
            // ✅ محاولة إعادة الاتصال
            await this.bucy.connect();
            
            // ✅ تحديث حالة الجلسة
            const session = this.activeSessions.get(cleaned);
            if (session) {
                session.status = 'repaired';
                session.repairedAt = Date.now();
                this.activeSessions.set(cleaned, session);
                this.bucy.logger?.success(`✅ Session ${cleaned} repaired successfully`);
            }

            return true;
        } catch (error) {
            this.bucy.logger?.error(`Failed to repair session ${cleaned}:`, error);
            return false;
        }
    }

    /**
     * تنظيف الجلسات التالفة
     */
    async cleanCorruptedSessions() {
        try {
            const sessionDir = this.sessionPath;
            if (!await fs.pathExists(sessionDir)) return;

            const sessions = await fs.readdir(sessionDir);
            let cleaned = 0;

            for (const session of sessions) {
                const sessionPath = path.join(sessionDir, session);
                const credsPath = path.join(sessionPath, 'creds.json');

                // ✅ التحقق من وجود ملفات الجلسة
                if (!await fs.pathExists(credsPath)) {
                    // ✅ حذف المجلد الفارغ أو التالف
                    await fs.remove(sessionPath);
                    cleaned++;
                    continue;
                }

                // ✅ التحقق من صحة الملفات
                try {
                    const creds = await fs.readJson(credsPath);
                    const required = ['noiseKey', 'signedIdentityKey', 'signedPreKey'];
                    let valid = true;
                    for (const key of required) {
                        if (!creds[key]) {
                            valid = false;
                            break;
                        }
                    }

                    if (!valid) {
                        // ✅ نقل الملف التالف إلى Backup
                        const backupPath = path.join(__dirname, '../Backups/corrupted');
                        await fs.ensureDir(backupPath);
                        await fs.copy(credsPath, path.join(backupPath, `${session}_${Date.now()}.json`));
                        await fs.remove(sessionPath);
                        cleaned++;
                    }
                } catch {
                    await fs.remove(sessionPath);
                    cleaned++;
                }
            }

            if (cleaned > 0) {
                this.bucy.logger?.info(`🧹 Cleaned ${cleaned} corrupted sessions`);
            }

        } catch (error) {
            this.bucy.logger?.error('Error cleaning corrupted sessions:', error);
        }
    }

    /**
     * الحصول على مسار جلسة رقم معين
     */
    getSessionPath(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        return path.join(this.sessionPath, cleaned);
    }

    /**
     * التحقق من وجود جلسة لرقم معين (مع Cache)
     */
    async sessionExists(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        
        // ✅ استخدام Cache
        if (this.sessionCache.has(cleaned)) {
            return this.sessionCache.get(cleaned);
        }

        const sessionDir = this.getSessionPath(cleaned);
        const credsPath = path.join(sessionDir, 'creds.json');
        const exists = await fs.pathExists(credsPath);
        
        // ✅ حفظ في Cache
        this.sessionCache.set(cleaned, exists);
        
        return exists;
    }

    /**
     * قفل جلسة لمنع التشغيل المتكرر
     */
    lockSession(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        if (this.lockedSessions.has(cleaned)) {
            return false;
        }
        this.lockedSessions.add(cleaned);
        this.bucy.logger?.debug(`🔒 Session locked: ${cleaned}`);
        return true;
    }

    /**
     * فتح جلسة
     */
    unlockSession(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        this.lockedSessions.delete(cleaned);
        this.bucy.logger?.debug(`🔓 Session unlocked: ${cleaned}`);
    }

    /**
     * تسجيل جلسة نشطة
     */
    registerActiveSession(phoneNumber, socket) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        this.activeSessions.set(cleaned, {
            phone: cleaned,
            socket: socket,
            startedAt: Date.now(),
            lastActivity: Date.now(),
            status: 'connected',
            integrity: 'valid'
        });
        
        // ✅ تحديث Cache
        this.sessionCache.set(cleaned, true);
        
        this.bucy.logger?.info(`📱 Session registered: ${cleaned}`);
    }

    /**
     * إزالة جلسة نشطة
     */
    async removeActiveSession(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        this.activeSessions.delete(cleaned);
        this.lockedSessions.delete(cleaned);
        this.sessionCache.delete(cleaned);
        this.bucy.logger?.info(`🗑️ Session removed: ${cleaned}`);
    }

    /**
     * تحديث آخر نشاط للجلسة
     */
    updateSessionActivity(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        const session = this.activeSessions.get(cleaned);
        if (session) {
            session.lastActivity = Date.now();
        }
    }

    /**
     * التحقق من صلاحية الجلسة
     */
    isSessionValid(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        const session = this.activeSessions.get(cleaned);
        if (!session) return false;
        
        const isExpired = Date.now() - session.lastActivity > this.sessionTimeout;
        if (isExpired) {
            this.removeActiveSession(cleaned);
            return false;
        }
        
        return session.status === 'connected' && session.integrity === 'valid';
    }

    /**
     * الحصول على جميع الجلسات النشطة
     */
    getActiveSessions() {
        const sessions = {};
        for (const [phone, data] of this.activeSessions) {
            sessions[phone] = {
                status: data.status,
                integrity: data.integrity || 'unknown',
                uptime: Math.floor((Date.now() - data.startedAt) / 1000),
                lastActivity: new Date(data.lastActivity).toISOString()
            };
        }
        return sessions;
    }

    /**
     * حذف جلسة (مع ملفاتها)
     */
    async deleteSession(phoneNumber) {
        const cleaned = phoneNumber.replace(/\D/g, '');
        const sessionDir = this.getSessionPath(cleaned);
        
        try {
            if (await fs.pathExists(sessionDir)) {
                await fs.remove(sessionDir);
                await this.removeActiveSession(cleaned);
                this.sessionCache.delete(cleaned);
                this.bucy.logger?.info(`🗑️ Session deleted: ${cleaned}`);
                return true;
            }
            return false;
        } catch (error) {
            this.bucy.logger?.error('Failed to delete session:', error);
            return false;
        }
    }

    /**
     * إعادة تعيين محاولات الاتصال
     */
    resetReconnectAttempts() {
        this.reconnectAttempts = 0;
    }

    /**
     * زيادة محاولات الاتصال
     */
    incrementReconnectAttempts() {
        this.reconnectAttempts++;
        return this.reconnectAttempts;
    }

    /**
     * التحقق من إمكانية إعادة المحاولة
     */
    canReconnect() {
        return this.reconnectAttempts < this.maxReconnectAttempts;
    }

    /**
     * الحصول على إحصائيات الجلسات
     */
    getStats() {
        return {
            activeSessions: this.activeSessions.size,
            lockedSessions: this.lockedSessions.size,
            cachedSessions: this.sessionCache.size,
            sessionTimeout: this.sessionTimeout / 1000,
            reconnectAttempts: this.reconnectAttempts,
            maxReconnectAttempts: this.maxReconnectAttempts,
            recoveryScheduler: this.recoveryInterval ? 'active' : 'stopped',
            sessions: this.getActiveSessions()
        };
    }
}

export default SessionManager;